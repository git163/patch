"""
Setup script for Image Algorithm package
"""

from setuptools import setup, find_packages

long_description = ""

setup(
    name="img-alg",
    version="0.1.0",
    author="Dev Team",
    author_email="team@example.com",
    description="图像分析系统 - 精确的斑点特性分析和ERF模型拟合",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/img_alg",
    project_urls={
        "Bug Tracker": "https://github.com/yourname/img_alg/issues",
        "Documentation": "https://github.com/yourname/img_alg#readme",
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0",
        "matplotlib>=3.5.0"
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
            "sphinx>=4.0",
            "sphinx-rtd-theme>=0.5.0",
        ],
        "gui": [
            "PyQt5>=5.15.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "img-alg=img_alg.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "img_alg": ["data/*.json", "config/*.json"],
    },
    zip_safe=False,
)