"""
算法处理层模块
负责点中心检测、边缘分析和ERF模型拟合
"""

from .base import BaseAnalyzer
from .factory import AnalyzerFactory
from .spot import SpotAnalyzer, SpotAlgorithm, center_of_mass
from .spot_lattice import (
    SpotLatticeAnalyzer,
    LatticeEdgeAlgorithm,
    LatticeAnomalyAnalyzer,
)
from .common.signal import detect_signal_type, estimate_background

__all__ = [
    "BaseAnalyzer",
    "AnalyzerFactory",
    "SpotAnalyzer",
    "SpotAlgorithm",
    "SpotLatticeAnalyzer",
    "LatticeEdgeAlgorithm",
    "LatticeAnomalyAnalyzer",
    "detect_signal_type",
    "estimate_background",
    "center_of_mass",
]

                                                                                
AnalyzerFactory.register("spot", SpotAnalyzer)
AnalyzerFactory.register("lattice", SpotLatticeAnalyzer)
AnalyzerFactory.register("lattice_anomaly", LatticeAnomalyAnalyzer)
