
import numpy as np


def estimate_background(data: np.ndarray, bins: int = 256) -> float:
    """用直方图峰值估计背景。背景像素数量最多，对边缘噪声和点大面积均鲁棒。

    Parameters
    ----------
    data : np.ndarray
        输入图像数据。
    bins : int, optional
        直方图分箱数，默认 256。

    Returns
    -------
    float
        估计的背景值。若输入为空数组则返回 0.0。
    """
    if data.size == 0:
        return 0.0

    hist, bin_edges = np.histogram(data.ravel(), bins=bins)
    peak_idx = int(np.argmax(hist))

                                 
    if 0 < peak_idx < len(hist) - 1:
        left = float(hist[peak_idx - 1])
        center = float(hist[peak_idx])
        right = float(hist[peak_idx + 1])
        denom = left - 2.0 * center + right
        if abs(denom) > 1e-12:
            shift = 0.5 * (left - right) / denom
            shift = max(-0.5, min(0.5, shift))
            peak_val = (bin_edges[peak_idx] + bin_edges[peak_idx + 1]) / 2.0
            bin_width = bin_edges[peak_idx + 1] - bin_edges[peak_idx]
            return float(peak_val + shift * bin_width)

    return float((bin_edges[peak_idx] + bin_edges[peak_idx + 1]) / 2.0)


def calculate_snr(data: np.ndarray) -> float:
    """计算信噪比"""
    signal = np.max(data) - np.mean(data)
    noise = np.std(data)
    return signal / noise if noise > 0 else float('inf')


def detect_signal_type(x_data: np.ndarray, y_data: np.ndarray) -> str:
    """检测信号类型（双边/单边上升/单边下降）"""
                 
    gradient = np.gradient(y_data)

                        
    if isinstance(gradient, tuple):
                  
        gradient = gradient[0]

    positive_gradients = np.sum(gradient > 0)
    negative_gradients = np.sum(gradient < 0)

                         
                          
    total_gradients = positive_gradients + negative_gradients
    is_bilateral = (positive_gradients > 0 and negative_gradients > 0 and
                    abs(positive_gradients - negative_gradients) < total_gradients * 0.6)

    if is_bilateral:
        return 'bilateral_erf'

                          
    if positive_gradients >= negative_gradients:
        return 'unilateral_rising_erf'
    else:
        return 'unilateral_falling_erf'
