"""
阵列列差异检测分析器
通过对比开启/关闭两张图像，识别常亮或常暗点
"""

import os
from typing import Tuple, Dict, Any, Optional, List
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

from ..base import BaseAnalyzer
from .core import LatticeEdgeAlgorithm
from ...datasets import make_spot_lattice
from ...utils import Logger, save_json, save_csv, ensure_dir, save_figure


class LatticeAnomalyAnalyzer(BaseAnalyzer):
    """阵列列差异检测分析器"""

    def __init__(self):
        super().__init__()
        self.algorithm = LatticeEdgeAlgorithm()
        self._raw_on: Optional[np.ndarray] = None
        self._raw_off: Optional[np.ndarray] = None

    def _do_process(self) -> Tuple[int, Optional[Dict[str, Any]]]:
        """
        主处理逻辑，由基类 process(params) 统一调度。

        运行时参数通过 self.get_param(key) 从参数字典中读取：
            - data_on / data_off: 直接传入的两张图像数据
            - input_file_on / input_file_off: real 模式下的输入文件路径
            - n_spots: 阵列行列数 (nx, ny)，默认 (3, 3)
            - spot_spacing: 近似点间距（像素），默认 50.0
            - mode: 'simulation' 或 'real'，默认 'real'
            - diff_ratio_threshold: ratio 阈值，默认 2.0
            - intensity_threshold: 用于区分常亮/常暗的 I_on 阈值，默认 'median'
            - enable_feature_matching: 是否基于特征匹配对 image_off 与 image_on 进行坐标统一，默认 False
            - 其余键作为 sim_params 传给 make_spot_lattice（仅 simulation 且无 data 时）

        Returns
        -------
        tuple
            (error_code, results)
            error_code: 0=成功, 1=文件错误, 2=数据错误, 3=算法错误
        """
        n_spots = self.get_param("n_spots", (3, 3))
        spot_spacing = self.get_param("spot_spacing", 50.0)
        mode = self.get_mode()
        diff_ratio_threshold = self.get_param("diff_ratio_threshold", 2.0)
        intensity_threshold = self.get_param("intensity_threshold", "median")

        if isinstance(n_spots, int):
            nx = ny = n_spots
        else:
            nx, ny = n_spots

        raw_on, raw_off = self._load_image_pair(nx, ny, spot_spacing, mode)
        if raw_on is None or raw_off is None:
            return 1, None

        enable_feature_matching = self.get_param("enable_feature_matching", False)
        if enable_feature_matching:
            from .feature_matching import match_images_by_features
            raw_off = match_images_by_features(raw_off, raw_on, (nx, ny), spot_spacing)

        self._raw_on = raw_on
        self._raw_off = raw_off

        spots = self._detect_candidate_spots(raw_on, raw_off, nx, ny, spot_spacing)
        if spots is None or len(spots) == 0:
            Logger.error("No candidate spots found in either image")
            return 3, {
                "error": "no_spots_found",
                "always_on": [],
                "always_off": [],
                "normal": [],
                "spot_centers": [],
                "success": False,
            }

        results = self._classify_spots(
            raw_on,
            raw_off,
            spots,
            diff_ratio_threshold=diff_ratio_threshold,
            intensity_threshold=intensity_threshold,
        )
        return 0, results

    def _load_image_pair(
        self,
        nx: int,
        ny: int,
        spot_spacing: float,
        mode: str,
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """加载或生成 image_on / image_off 数据对。"""
        data_on = self.get_param("data_on")
        data_off = self.get_param("data_off")

        if data_on is not None and data_off is not None:
            return np.array(data_on, dtype=np.float64), np.array(data_off, dtype=np.float64)

        input_file_on = self.get_param("input_file_on")
        input_file_off = self.get_param("input_file_off")

        if input_file_on and input_file_off:
            raw_on = self._load_image_file(input_file_on)
            raw_off = self._load_image_file(input_file_off)
            return raw_on, raw_off

        if mode == "simulation":
            reserved = {
                "data_on", "data_off", "input_file_on", "input_file_off",
                "n_spots", "spot_spacing", "mode",
                "diff_ratio_threshold", "intensity_threshold",
            }
            sim_params = {k: v for k, v in self.params.items() if k not in reserved}
            raw_on = self._generate_simulation_data(nx, ny, spot_spacing, **sim_params)
                                                       
            off_params = dict(sim_params)
            total_spots = nx * ny
            off_params["spot_mask"] = [0.0] * total_spots
            raw_off = self._generate_simulation_data(nx, ny, spot_spacing, **off_params)
            return raw_on, raw_off

        Logger.error(
            "LatticeAnomalyAnalyzer requires data_on/data_off or input_file_on/input_file_off"
        )
        return None, None

    def _load_image_file(self, path: str) -> Optional[np.ndarray]:
        """从文件加载图像数据。"""
        try:
            img = Image.open(path)
            if img.mode != "L":
                img = img.convert("L")
            raw_data = np.array(img, dtype=np.float64)
            Logger.info("Loaded image: %s, shape=%s", path, raw_data.shape)
            return raw_data
        except Exception as e:
            Logger.error("Failed to load image %s: %s", path, e)
            return None

    def _generate_simulation_data(
        self,
        nx: int,
        ny: int,
        spot_spacing: float,
        **sim_params,
    ) -> np.ndarray:
        """生成仿真阵列数据。"""
        return make_spot_lattice(
            n_spots=(nx, ny),
            spot_spacing=spot_spacing,
            **sim_params,
        )

    def _detect_candidate_spots(
        self,
        data_on: np.ndarray,
        data_off: np.ndarray,
        nx: int,
        ny: int,
        spot_spacing: float,
    ) -> Optional[np.ndarray]:
        """在两幅图上分别检测点，合并为统一候选集。"""
        expected_n = nx * ny * 2                 
        spots_on = self.algorithm._detect_spots(data_on, expected_n, spot_spacing)

                                                
        from scipy.ndimage import gaussian_filter
        smoothed_off = gaussian_filter(data_off.astype(np.float64), sigma=1.0)
        mean_off = float(smoothed_off.mean())
        std_off = float(smoothed_off.std())
        threshold_off = mean_off + 5.0 * std_off
        spots_off = self.algorithm._detect_spots(data_off, expected_n, spot_spacing, threshold=threshold_off)

        if (spots_on is None or len(spots_on) == 0) and (spots_off is None or len(spots_off) == 0):
            return None

        if spots_on is None or len(spots_on) == 0:
            return spots_off
        if spots_off is None or len(spots_off) == 0:
            return spots_on

        candidates = spots_on.copy()
        merge_dist = spot_spacing * 0.3
        for pt_off in spots_off:
            dists = np.linalg.norm(candidates - pt_off, axis=1)
            if dists.min() > merge_dist:
                candidates = np.vstack([candidates, pt_off])
        return candidates

    def _extract_intensities(
        self,
        data: np.ndarray,
        spots: np.ndarray,
        spot_spacing: float,
    ) -> np.ndarray:
        """在每个候选点周围提取局部平均强度。"""
        window = max(3, int(spot_spacing * 0.25))
        h, w = data.shape
        intensities = []
        for x, y in spots:
            x0 = max(0, int(np.round(x)) - window)
            x1 = min(w, int(np.round(x)) + window + 1)
            y0 = max(0, int(np.round(y)) - window)
            y1 = min(h, int(np.round(y)) + window + 1)
            patch = data[y0:y1, x0:x1]
            intensities.append(float(patch.mean()) if patch.size > 0 else 0.0)
        return np.array(intensities)

    def _classify_spots(
        self,
        data_on: np.ndarray,
        data_off: np.ndarray,
        spots: np.ndarray,
        diff_ratio_threshold: float,
        intensity_threshold: Any,
    ) -> Dict[str, Any]:
        """基于 ratio 与绝对亮度对候选点进行分类。"""
        spot_spacing = self.get_param("spot_spacing", 50.0)
        I_on = self._extract_intensities(data_on, spots, spot_spacing)
        I_off = self._extract_intensities(data_off, spots, spot_spacing)

        eps = 1e-6
        ratio = I_on / (I_off + eps)

                                      
        bg_on = float(np.percentile(data_on, 5))
        bg_off = float(np.percentile(data_off, 5))

                                                       
        valid_on = I_on[I_on > bg_on + 1e-3]
        normal_ref = float(np.median(valid_on)) if len(valid_on) > 0 else 1.0

        always_on: List[Dict[str, Any]] = []
        always_off: List[Dict[str, Any]] = []
        normal: List[Dict[str, Any]] = []

        on_threshold = bg_on + 0.3 * normal_ref
        off_threshold = bg_off + 0.3 * normal_ref

        for i, (x, y) in enumerate(spots):
            pt = {
                "x": float(x),
                "y": float(y),
                "I_on": float(I_on[i]),
                "I_off": float(I_off[i]),
                "ratio": float(ratio[i]),
            }
            on_strong = I_on[i] > on_threshold
            off_strong = I_off[i] > off_threshold

            if not on_strong and not off_strong:
                always_off.append(pt)
            elif on_strong and not off_strong:
                normal.append(pt)
            elif off_strong and ratio[i] < diff_ratio_threshold:
                                                   
                always_on.append(pt)
            else:
                                                                               
                        
                normal.append(pt)

        return {
            "always_on": always_on,
            "always_off": always_off,
            "normal": normal,
            "spot_centers": spots.tolist(),
            "threshold": diff_ratio_threshold,
            "intensity_threshold": normal_ref,
            "bg_on": bg_on,
            "bg_off": bg_off,
            "success": True,
            "error": None,
        }

    def plot_results(
        self,
        results: Optional[Dict[str, Any]] = None,
        output_path: Optional[str] = None,
        title: Optional[str] = None,
    ) -> None:
        """绘制差异检测结果。"""
        if results is None:
            results = self.results
        if not results:
            Logger.warning("No results to display")
            return

        if self._raw_on is None:
            Logger.warning("No raw_on data available for plotting")
            return

        data = self._raw_on
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.imshow(data, cmap="gray", origin="upper")

        always_on = results.get("always_on", [])
        always_off = results.get("always_off", [])
        normal = results.get("normal", [])

        if normal:
            ax.scatter(
                [pt["x"] for pt in normal],
                [pt["y"] for pt in normal],
                c="white",
                s=30,
                marker="o",
                label="Normal",
            )
        if always_on:
            ax.scatter(
                [pt["x"] for pt in always_on],
                [pt["y"] for pt in always_on],
                c="lime",
                s=120,
                marker="o",
                facecolors="none",
                edgecolors="lime",
                linewidths=2,
                label="Always On",
            )
        if always_off:
            ax.scatter(
                [pt["x"] for pt in always_off],
                [pt["y"] for pt in always_off],
                c="red",
                s=120,
                marker="o",
                facecolors="none",
                edgecolors="red",
                linewidths=2,
                label="Always Off",
            )

        ax.set_title(title or "Lattice Anomaly Detection")
        ax.set_xlabel("X Pixel")
        ax.set_ylabel("Y Pixel")
        ax.legend(loc="upper right")

        if output_path is not None:
            save_figure(fig, output_path)
        else:
            plt.show()
            plt.close(fig)

    def save_results(
        self,
        results: Optional[Dict[str, Any]] = None,
        output_dir: str = "results",
    ) -> bool:
        """保存结果到 JSON/CSV 文件。"""
        if results is None:
            results = self.results
        if not results:
            Logger.warning("No results to save")
            return False

        try:
            ensure_dir(os.path.join(output_dir, ".placeholder"))

            save_json(results, os.path.join(output_dir, "lattice_anomaly_results.json"))

            anomalies = results.get("always_on", []) + results.get("always_off", [])
            if anomalies:
                rows = [[pt["x"], pt["y"], pt["I_on"], pt["I_off"], pt["ratio"]] for pt in anomalies]
                save_csv(
                    rows,
                    os.path.join(output_dir, "anomaly_spots.csv"),
                    headers=["x", "y", "I_on", "I_off", "ratio"],
                )

            Logger.info("Lattice anomaly results saved to %s", output_dir)
            return True
        except Exception as e:
            Logger.error("Failed to save lattice anomaly results: %s", e)
            return False
