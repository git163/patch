"""
SpotLattice 业务绘图模块
负责畸变斑点点阵分析相关的可视化与报告生成
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, Optional

from ...utils import save_figure


class SpotLatticePlotter:
    """点阵分析结果绘图器"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化绘图器

        Args:
            config: 可视化配置字典，可选
        """
        self.config = config or {}
        self.colormap = self.config.get('colormap', 'YlGnBu')
        self.dpi = self.config.get('image_dpi', 150)

    def plot_lattice_edge_analysis(
        self,
        data: np.ndarray,
        results: Dict[str, Any],
        output_path: Optional[str] = None,
        title: str = "Distorted Lattice Edge Analysis",
    ) -> None:
        """
        绘制点阵边缘分析结果

        Args:
            data: 预处理后的2D图像数据
            results: lattice分析结果字典
            output_path: 输出路径，若提供则保存为PNG
            title: 图像标题，用于区分不同配置/场景
        """
        fig, ax = plt.subplots(figsize=(10, 10))

              
        im = ax.imshow(data, cmap=self.colormap, origin='upper')
        plt.colorbar(im, ax=ax, label='Intensity')

                    
        spot_centers = np.array(results.get('spot_centers', []))
        if len(spot_centers) > 0:
            ax.scatter(spot_centers[:, 0], spot_centers[:, 1], c='white', s=30, marker='o', label='Spot Centers')

                       
        edge_colors = {
            'top': 'red',
            'bottom': 'blue',
            'left': 'green',
            'right': 'orange',
        }
        edge_fits = results.get('edge_fits', {})
        edge_spots = results.get('edge_spots', {})
        edge_centers = results.get('edge_centers', {})

        for edge_name, color in edge_colors.items():
            spots = np.array(edge_spots.get(edge_name, []))
            fit_info = edge_fits.get(edge_name, {})

            if len(spots) > 0:
                        
                ax.scatter(spots[:, 0], spots[:, 1], c=color, s=80, marker='s', edgecolors='k', alpha=0.6)

                        
                coeffs = fit_info.get('coeffs', [])
                axis = fit_info.get('axis', 'horizontal')
                if len(coeffs) > 0:
                    if axis == 'horizontal':
                        x_vals = np.linspace(spots[:, 0].min(), spots[:, 0].max(), 100)
                        y_vals = np.polyval(coeffs, x_vals)
                        ax.plot(x_vals, y_vals, color=color, linestyle='--', linewidth=2, label=f'{edge_name} fit')
                    else:
                        y_vals = np.linspace(spots[:, 1].min(), spots[:, 1].max(), 100)
                        x_vals = np.polyval(coeffs, y_vals)
                        ax.plot(x_vals, y_vals, color=color, linestyle='--', linewidth=2, label=f'{edge_name} fit')

                   
            center = edge_centers.get(edge_name)
            if center is not None:
                ax.scatter(center[0], center[1], c=color, s=200, marker='D', edgecolors='black', linewidths=1.5, zorder=5)

                  
        lattice_center = results.get('lattice_center')
        if lattice_center is not None:
            ax.plot(lattice_center[0], lattice_center[1], 'r+', markersize=20, markeredgewidth=3, label='Lattice Center')

        ax.set_title(title)
        ax.set_xlabel('X Pixel')
        ax.set_ylabel('Y Pixel')
        ax.legend(loc='upper right', fontsize=8)

        if output_path:
            save_figure(fig, output_path, dpi=self.dpi)
        else:
            plt.show()
            plt.close(fig)

    def save_lattice_summary_report(
        self,
        results: Dict[str, Any],
        output_path: str,
    ) -> None:
        """
        保存点阵边缘分析摘要报告

        Args:
            results: lattice分析结果字典
            output_path: 报告输出路径
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("Lattice Edge Analysis Report\n")
            f.write("=" * 50 + "\n\n")

            lattice_center = results.get('lattice_center')
            if lattice_center is not None:
                f.write(f"Lattice Center: X={lattice_center[0]:.3f}, Y={lattice_center[1]:.3f}\n\n")

            edge_centers = results.get('edge_centers', {})
            edge_fits = results.get('edge_fits', {})

            for edge_name in ['top', 'bottom', 'left', 'right']:
                center = edge_centers.get(edge_name)
                fit = edge_fits.get(edge_name, {})
                if center is not None:
                    f.write(f"{edge_name.capitalize()} Edge:\n")
                    f.write(f"  Center: X={center[0]:.3f}, Y={center[1]:.3f}\n")
                    f.write(f"  Fit Model: {fit.get('model', 'none')}\n")
                    f.write(f"  Fit Axis: {fit.get('axis', 'unknown')}\n")
                    coeffs = fit.get('coeffs', [])
                    if coeffs:
                        f.write(f"  Coeffs: {coeffs}\n")
                    f.write("\n")

            f.write("=" * 50 + "\n")
            f.write("Analysis completed\n")
