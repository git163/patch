"""
点阵边缘中心定位算法实现
负责从畸变斑点点阵图像中提取四条边/弧的中心点以及整体中心
"""

from typing import Tuple, List, Dict, Optional
import numpy as np
from scipy import ndimage

from ..spot.center import center_of_mass
from ..common.signal import estimate_background
from ...utils import Logger


def _detect_local_peaks(data: np.ndarray, min_distance: int, threshold: float) -> np.ndarray:
    """
    使用局部最大值检测图像中的峰值点。

    Parameters
    ----------
    data : np.ndarray
        输入2D图像
    min_distance : int
        两个峰值之间的最小距离（像素）
    threshold : float
        强度阈值，仅保留高于该值的峰值

    Returns
    -------
    np.ndarray
        (N, 2) 峰值坐标数组，每行为 (row, col) 即 (y, x)
    """
                    
    footprint = np.ones((min_distance * 2 + 1, min_distance * 2 + 1), dtype=bool)
    local_max = ndimage.maximum_filter(data, footprint=footprint, mode="constant", cval=0)
    peak_mask = (data == local_max) & (data > threshold)

    peaks = np.argwhere(peak_mask)
    return peaks


def _refine_spots(data: np.ndarray, peaks: np.ndarray, window_size: int) -> np.ndarray:
    """
    在检测到的峰值附近使用质心法做亚像素精修。

    Parameters
    ----------
    data : np.ndarray
        输入2D图像
    peaks : np.ndarray
        (N, 2) 粗检测峰值坐标 (y, x)
    window_size : int
        局部窗口半宽（像素）

    Returns
    -------
    np.ndarray
        (N, 2) 精修后的斑点中心 (x, y)
    """
    h, w = data.shape
    refined = []
    for y, x in peaks:
        y0 = max(0, y - window_size)
        y1 = min(h, y + window_size + 1)
        x0 = max(0, x - window_size)
        x1 = min(w, x + window_size + 1)
        patch = data[y0:y1, x0:x1]
        cx, cy = center_of_mass(patch, use_erf_fit=False)
        refined.append([float(x0 + cx), float(y0 + cy)])
    return np.array(refined)


def _cluster_1d(points_1d: np.ndarray, n_clusters: int) -> List[np.ndarray]:
    """
    对一维有序点进行自然分群，利用相邻点间距的 gap 来划分。

    Parameters
    ----------
    points_1d : np.ndarray
        一维坐标数组
    n_clusters : int
        期望分成的簇数

    Returns
    -------
    List[np.ndarray]
        每个簇包含的原始索引数组列表
    """
    sorted_idx = np.argsort(points_1d)
    sorted_vals = points_1d[sorted_idx]
    diffs = np.diff(sorted_vals)

    n_clusters = int(n_clusters)
    if n_clusters <= 1 or len(sorted_vals) <= n_clusters:
        return [sorted_idx]

                                  
    n_gaps = n_clusters - 1
    if len(diffs) <= n_gaps:
                  
        split_positions = np.linspace(0, len(sorted_vals), n_clusters + 1, dtype=int)[1:-1]
    else:
        gap_indices = np.argpartition(diffs, -n_gaps)[-n_gaps:]
        gap_indices = np.sort(gap_indices)
        split_positions = gap_indices + 1

    clusters = []
    start = 0
    for sp in split_positions:
        clusters.append(sorted_idx[start:sp])
        start = sp
    clusters.append(sorted_idx[start:])
    return clusters


def _fit_edge(spots: np.ndarray, axis: str) -> Tuple[np.ndarray, Dict]:
    """
    对边界上的斑点进行低阶多项式拟合并提取边中心。

    Parameters
    ----------
    spots : np.ndarray
        (M, 2) 边界斑点坐标 (x, y)
    axis : str
        'horizontal' 表示上下边（y = f(x)）
        'vertical' 表示左右边（x = g(y)）

    Returns
    -------
    center : np.ndarray
        [x, y] 边中心坐标
    fit_info : dict
        包含 'coeffs'、'model'、'axis' 的拟合信息
    """
    if len(spots) < 2:
        center = spots.mean(axis=0) if len(spots) > 0 else np.array([0.0, 0.0])
        return center, {"coeffs": [], "model": "none", "axis": axis}

    if axis == "horizontal":
        x = spots[:, 0]
        y = spots[:, 1]
                                     
        coeffs = np.polyfit(x, y, min(2, len(x) - 1))
        xm = (x.min() + x.max()) / 2.0
        ym = np.polyval(coeffs, xm)
        center = np.array([float(xm), float(ym)])
    else:            
        y = spots[:, 1]
        x = spots[:, 0]
        coeffs = np.polyfit(y, x, min(2, len(y) - 1))
        ym = (y.min() + y.max()) / 2.0
        xm = np.polyval(coeffs, ym)
        center = np.array([float(xm), float(ym)])

    degree = len(coeffs) - 1
    fit_info = {
        "coeffs": coeffs.tolist(),
        "model": f"poly{degree}",
        "axis": axis,
    }
    return center, fit_info


def _line_intersection(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray, p4: np.ndarray) -> Optional[np.ndarray]:
    """
    计算两条线段所在直线的交点。
    p1-p2 为第一条线，p3-p4 为第二条线。
    若平行则返回 None。
    """
    x1, y1 = p1
    x2, y2 = p2
    x3, y3 = p3
    x4, y4 = p4

    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-10:
        return None

    px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denom
    py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denom
    return np.array([float(px), float(py)])


class LatticeEdgeAlgorithm:
    """点阵边缘中心定位算法"""

    def __init__(self):
        self.results = {}

    def analyze_lattice(
        self,
        data: np.ndarray,
        n_spots: Tuple[int, int],
        spot_spacing: float,
    ) -> Dict:
        """
        分析畸变点阵图像，返回边缘中心与整体中心。

        Parameters
        ----------
        data : np.ndarray
            输入点阵图像（2D 数组）
        n_spots : tuple(int, int)
            期望的点阵行列数 (nx, ny)
        spot_spacing : float
            近似斑点间距（像素），用于界定局部搜索窗口

        Returns
        -------
        dict
            分析结果字典
        """
        nx, ny = n_spots
        expected_n = int(nx * ny)

                 
        spots = self._detect_spots(data, expected_n, spot_spacing)
        if spots is None or len(spots) == 0:
            Logger.error("Lattice spot detection failed: no spots found")
            return self._failure_result("spot_detection_failed")

                   
        grid = self._organize_grid(spots, nx, ny)
        if grid is None:
            Logger.error("Lattice grid organization failed")
            return self._failure_result("grid_organization_failed")

                       
        edge_centers = {}
        edge_fits = {}
        for edge_name, edge_spots in grid.items():
            axis = "horizontal" if edge_name in ("top", "bottom") else "vertical"
            center, fit_info = _fit_edge(edge_spots, axis)
            edge_centers[edge_name] = center.tolist()
            edge_fits[edge_name] = fit_info

                   
        top_c = np.array(edge_centers["top"])
        bottom_c = np.array(edge_centers["bottom"])
        left_c = np.array(edge_centers["left"])
        right_c = np.array(edge_centers["right"])

        lattice_center = _line_intersection(top_c, bottom_c, left_c, right_c)
        if lattice_center is None:
            lattice_center = (top_c + bottom_c + left_c + right_c) / 4.0
        lattice_center = lattice_center.tolist()

        return {
            "spot_centers": spots.tolist(),
            "edge_spots": {k: v.tolist() for k, v in grid.items()},
            "edge_centers": edge_centers,
            "lattice_center": lattice_center,
            "edge_fits": edge_fits,
            "success": True,
            "error": None,
        }

    def _detect_spots(
        self,
        data: np.ndarray,
        expected_n: int,
        spot_spacing: float,
    ) -> Optional[np.ndarray]:
        """检测所有斑点中心，返回 (N, 2) 数组（x, y）。"""
                             
        from scipy.ndimage import gaussian_filter
        smoothed = gaussian_filter(data.astype(np.float64), sigma=1.0)

                                        
                             
        mean_val = float(smoothed.mean())
        std_val = float(smoothed.std())
        threshold = mean_val + 0.5 * std_val

        min_distance = max(3, int(spot_spacing * 0.4))
        peaks = _detect_local_peaks(smoothed, min_distance=min_distance, threshold=threshold)
        Logger.info("Detected %d raw peaks, expected %d", len(peaks), expected_n)

        if len(peaks) == 0:
                      
            threshold = mean_val
            peaks = _detect_local_peaks(smoothed, min_distance=min_distance, threshold=threshold)
            if len(peaks) == 0:
                return None

                                               
        if len(peaks) > expected_n * 2:
            intensities = smoothed[peaks[:, 0], peaks[:, 1]]
            top_idx = np.argsort(intensities)[-expected_n * 2:]
            peaks = peaks[top_idx]

               
        window_size = max(2, int(spot_spacing * 0.25))
        refined = _refine_spots(data, peaks, window_size)

                                            
        if len(refined) > expected_n:
            intensities = data[peaks[:, 0], peaks[:, 1]]
            top_idx = np.argsort(intensities)[-expected_n:]
            refined = refined[top_idx]

        return refined

    def _organize_grid(
        self,
        spots: np.ndarray,
        nx: int,
        ny: int,
    ) -> Optional[Dict[str, np.ndarray]]:
        """将斑点组织为行列结构，返回各边界点集。"""
        if len(spots) < max(nx, ny):
            return None

                                                
        col_clusters = _cluster_1d(spots[:, 0], nx)
        row_clusters = _cluster_1d(spots[:, 1], ny)

                                  
        col_ok = all(abs(len(c) - ny) <= max(1, ny // 2) for c in col_clusters)
        row_ok = all(abs(len(c) - nx) <= max(1, nx // 2) for c in row_clusters)

        if not (col_ok and row_ok):
                                     
            grid_pca = self._organize_grid_pca(spots, nx, ny)
            if grid_pca is not None:
                return grid_pca
                                                

                
        col_means = [spots[c, 0].mean() for c in col_clusters]
        row_means = [spots[c, 1].mean() for c in row_clusters]
        left_idx = int(np.argmin(col_means))
        right_idx = int(np.argmax(col_means))
        top_idx = int(np.argmin(row_means))
        bottom_idx = int(np.argmax(row_means))

        return {
            "top": spots[row_clusters[top_idx]],
            "bottom": spots[row_clusters[bottom_idx]],
            "left": spots[col_clusters[left_idx]],
            "right": spots[col_clusters[right_idx]],
        }

    @staticmethod
    def _is_row_cluster(clusters: List[np.ndarray], spots: np.ndarray) -> bool:
        """
        判断这些簇是否表示行（水平条带）。
        行的特点是 x 跨度大、y 跨度小（std_x > std_y）。
        """
        ratios = []
        for c in clusters:
            if len(c) > 1:
                std_x = float(np.std(spots[c, 0]))
                std_y = float(np.std(spots[c, 1]))
                ratios.append(std_x / max(std_y, 1e-6))
        return float(np.mean(ratios)) > 1.0 if ratios else True

    def _organize_grid_pca(
        self,
        spots: np.ndarray,
        nx: int,
        ny: int,
    ) -> Optional[Dict[str, np.ndarray]]:
        """使用 PCA 主方向投影聚类（备用方案）。"""
        centered = spots - spots.mean(axis=0)
        cov = np.cov(centered.T)
        eigvals, eigvecs = np.linalg.eigh(cov)
        order = np.argsort(eigvals)[::-1]
        eigvecs = eigvecs[:, order]

        proj1 = centered @ eigvecs[:, 0]
        proj2 = centered @ eigvecs[:, 1]

                                 
                                        
        clusters1_a = _cluster_1d(proj1, ny)
        clusters2_a = _cluster_1d(proj2, nx)
        variance_a = (
            sum(np.var(proj1[c]) for c in clusters1_a if len(c) > 0) / max(len(clusters1_a), 1)
            + sum(np.var(proj2[c]) for c in clusters2_a if len(c) > 0) / max(len(clusters2_a), 1)
        )

                 
        clusters1_b = _cluster_1d(proj1, nx)
        clusters2_b = _cluster_1d(proj2, ny)
        variance_b = (
            sum(np.var(proj1[c]) for c in clusters1_b if len(c) > 0) / max(len(clusters1_b), 1)
            + sum(np.var(proj2[c]) for c in clusters2_b if len(c) > 0) / max(len(clusters2_b), 1)
        )

                        
        if variance_a <= variance_b:
            candidate_rows, candidate_cols = clusters1_a, clusters2_a
        else:
            candidate_rows, candidate_cols = clusters1_b, clusters2_b

                                                              
        if self._is_row_cluster(candidate_rows, spots):
            row_clusters = candidate_rows
            col_clusters = candidate_cols
        else:
            row_clusters = candidate_cols
            col_clusters = candidate_rows

                
        row_means = [spots[c, 1].mean() for c in row_clusters]
        col_means = [spots[c, 0].mean() for c in col_clusters]
        top_idx = int(np.argmin(row_means))
        bottom_idx = int(np.argmax(row_means))
        left_idx = int(np.argmin(col_means))
        right_idx = int(np.argmax(col_means))

        return {
            "top": spots[row_clusters[top_idx]],
            "bottom": spots[row_clusters[bottom_idx]],
            "left": spots[col_clusters[left_idx]],
            "right": spots[col_clusters[right_idx]],
        }

    def _failure_result(self, error: str) -> Dict:
        """构建失败结果字典。"""
        return {
            "spot_centers": [],
            "edge_spots": {},
            "edge_centers": {},
            "lattice_center": [0.0, 0.0],
            "edge_fits": {},
            "success": False,
            "error": error,
        }
