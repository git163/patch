"""
畸变斑点点阵分析器主类
提供用户接口和主要处理流程，支持 real / simulation 两种数据模式
"""

import os
from typing import Tuple, Dict, Any, Optional
import numpy as np
from PIL import Image

from .core import LatticeEdgeAlgorithm
from ..base import BaseAnalyzer
from .plotting import SpotLatticePlotter
from ...datasets import make_spot_lattice
from ...preprocessing import ClipOutliers, GaussianFilter, MinMaxScaler
from ...utils import Logger, save_json, save_csv, ensure_dir


class SpotSpotLatticeAnalyzer(BaseAnalyzer):
    """畸变斑点点阵分析器主类"""

    def __init__(self, plotter: Optional[SpotLatticePlotter] = None):
        super().__init__()
        self.algorithm = LatticeEdgeAlgorithm()
        self.plotter = plotter or SpotLatticePlotter({})

    def _do_process(self) -> Tuple[int, Optional[Dict[str, Any]]]:
        """
        主处理逻辑，由基类 process(params) 统一调度。

        运行时参数通过 self.get_param(key) 从参数字典中读取：
            - data: 直接传入的图像数据
            - input_file: real 模式下的输入图像文件路径
            - n_spots: 点阵行列数 (nx, ny)，默认 (3, 3)
            - spot_spacing: 近似斑点间距（像素），默认 50.0
            - mode: 'simulation' 或 'real'，默认 'simulation'
            - 其余键作为 sim_params 传给 make_spot_lattice

        Returns
        -------
        tuple
            (error_code, results)
            error_code: 0=成功, 1=文件错误, 2=数据错误, 3=算法错误
        """
        data = self.get_param("data")
        input_file = self.get_param("input_file")
        n_spots = self.get_param("n_spots", (3, 3))
        spot_spacing = self.get_param("spot_spacing", 50.0)
        mode = self.get_mode()

                         
        reserved = {"data", "input_file", "n_spots", "spot_spacing", "mode"}
        sim_params = {k: v for k, v in self.params.items() if k not in reserved}

                    
        if data is None:
            if mode == "simulation":
                raw_data = self._generate_simulation_data(
                    n_spots=n_spots,
                    spot_spacing=spot_spacing,
                    **sim_params,
                )
            else:
                raw_data = self._load_real_data(input_file)
                if raw_data is None:
                    return 1, None
        else:
            raw_data = np.array(data, dtype=np.float64)

                
        processed_data = self._apply_preprocessing(raw_data)

                 
        alg_results = self.algorithm.analyze_lattice(
            processed_data,
            n_spots=n_spots,
            spot_spacing=spot_spacing,
        )

        if not alg_results.get("success", False):
            Logger.error("Lattice analysis failed: %s", alg_results.get("error"))
            return 3, alg_results

                 
        results = self._build_results(raw_data, processed_data, alg_results)
        return 0, results

    def _generate_simulation_data(
        self,
        n_spots: Tuple[int, int],
        spot_spacing: float,
        image_size: int = 1024,
        amplitude: float = 1.0,
        sigma: float = 8.0,
        noise_level: float = 0.02,
        **sim_params,
    ) -> np.ndarray:
        """生成仿真点阵数据。"""
        return make_spot_lattice(
            image_size=image_size,
            n_spots=n_spots,
            spot_spacing=spot_spacing,
            amplitude=amplitude,
            sigma=sigma,
            noise_level=noise_level,
            **sim_params,
        )

    def _load_real_data(self, input_file: Optional[str]) -> Optional[np.ndarray]:
        """从文件加载真实数据（支持 TIFF/PNG 等图像格式）。"""
        input_file = input_file or self._find_default_input_file()
        if not input_file:
            Logger.error("Real data mode requires input_file")
            return None

        try:
            img = Image.open(input_file)
                   
            if img.mode != "L":
                img = img.convert("L")
            raw_data = np.array(img, dtype=np.float64)
            Logger.info("Loaded real image: %s, shape=%s", input_file, raw_data.shape)
            return raw_data
        except Exception as e:
            Logger.error("Failed to load image %s: %s", input_file, e)
            return None

    def _find_default_input_file(self) -> Optional[str]:
        """自动查找默认输入文件。"""
        origin_dir = "data/origin_csv"
        os.makedirs(origin_dir, exist_ok=True)

                           
        for ext in (".tif", ".tiff", ".png", ".jpg", ".jpeg", ".csv"):
            files = [
                f for f in os.listdir(origin_dir)
                if f.lower().startswith("origin_") and f.lower().endswith(ext)
            ]
            if files:
                input_file = os.path.join(origin_dir, files[0])
                Logger.info("No input file specified, auto-using: %s", input_file)
                return input_file

        Logger.error("Real data mode requires input_file (must start with origin_)")
        return None

    def _apply_preprocessing(self, raw_data: np.ndarray) -> np.ndarray:
        """应用数据预处理。"""
                                                     
                                  
                                                        
        return raw_data.copy()

    def _build_results(
        self,
        raw_data: np.ndarray,
        processed_data: np.ndarray,
        alg_results: Dict[str, Any],
    ) -> Dict[str, Any]:
        """构建结果字典。"""
        return {
            "original_data": raw_data.tolist(),
            "processed_data": processed_data.tolist(),
            "spot_centers": alg_results["spot_centers"],
            "edge_spots": alg_results["edge_spots"],
            "edge_centers": alg_results["edge_centers"],
            "lattice_center": alg_results["lattice_center"],
            "edge_fits": alg_results["edge_fits"],
            "success": alg_results["success"],
            "error": alg_results["error"],
            "metadata": {
                "image_size": processed_data.shape,
                "algorithm_version": "0.1.0",
            },
        }

    def plot_results(
        self,
        results: Optional[Dict[str, Any]] = None,
        output_path: Optional[str] = None,
        title: Optional[str] = None,
    ) -> None:
        """调用 visualizer 绘制点阵分析结果。"""
        if results is None:
            results = self.results

        if not results:
            Logger.warning("No results to display")
            return

        data = np.array(results["processed_data"])
        self.plotter.plot_lattice_edge_analysis(
            data,
            results,
            output_path=output_path,
            title=title or "Distorted Lattice Edge Analysis",
        )

    def save_results(
        self,
        results: Optional[Dict[str, Any]] = None,
        output_dir: str = "results",
    ) -> bool:
        """保存结果到 JSON/CSV 文件。"""
        if results is None:
            results = self.results
        if not results:
            Logger.warning("No results to save")
            return False

        try:
            ensure_dir(os.path.join(output_dir, ".placeholder"))

                          
            save_json(results, os.path.join(output_dir, "lattice_results.json"))

                          
            spot_centers = results.get("spot_centers", [])
            if spot_centers:
                save_csv(
                    [[i, c[0], c[1]] for i, c in enumerate(spot_centers)],
                    os.path.join(output_dir, "spot_centers.csv"),
                    headers=["index", "x", "y"],
                )

            edge_centers = results.get("edge_centers", {})
            if edge_centers:
                save_json(edge_centers, os.path.join(output_dir, "edge_centers.json"))

            edge_fits = results.get("edge_fits", {})
            if edge_fits:
                save_json(edge_fits, os.path.join(output_dir, "edge_fits.json"))

                       
            summary_path = os.path.join(output_dir, "lattice_analysis_summary.txt")
            self.plotter.save_lattice_summary_report(results, summary_path)

            Logger.info("Lattice results saved to %s", output_dir)
            return True
        except Exception as e:
            Logger.error("Failed to save lattice results: %s", e)
            return False
