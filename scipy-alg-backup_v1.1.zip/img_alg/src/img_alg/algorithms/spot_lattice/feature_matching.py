"""
基于点中心特征点 + Similarity Transform（Umeyama 算法），
通过特征匹配消除两图之间的几何差异。
纯 numpy/scipy 实现，无需 OpenCV。
"""

from typing import Tuple
import numpy as np
from scipy import ndimage
from scipy.spatial import cKDTree

from .core import LatticeEdgeAlgorithm
from ...utils import Logger


def _extract_keypoints(
    data: np.ndarray,
    expected_n: int,
    spot_spacing: float,
) -> np.ndarray:
    """从阵列图像中提取点中心作为特征点，使用较高阈值抑制背景/边界噪声。"""
    from scipy.ndimage import gaussian_filter
    smoothed = gaussian_filter(data.astype(np.float64), sigma=1.0)
    mean_val = float(smoothed.mean())
    std_val = float(smoothed.std())
    threshold = mean_val + 2.0 * std_val
    alg = LatticeEdgeAlgorithm()
    spots = alg._detect_spots(data, expected_n, spot_spacing, threshold=threshold)
    return spots if spots is not None else np.empty((0, 2), dtype=np.float64)


def _match_keypoints(
    pts_on: np.ndarray,
    pts_off: np.ndarray,
    spot_spacing: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    对两套特征点进行匹配，返回 (matched_on, matched_off)。
    先用质心做粗对齐，再用 KDTree 最近邻搜索，最后过滤离群点并保证一对一。
    """
    if len(pts_off) == 0 or len(pts_on) == 0:
        return np.empty((0, 2), dtype=np.float64), np.empty((0, 2), dtype=np.float64)

              
    centroid_on = pts_on.mean(axis=0)
    centroid_off = pts_off.mean(axis=0)
    pts_off_coarse = pts_off + (centroid_on - centroid_off)

    tree = cKDTree(pts_on)
    distances, indices = tree.query(pts_off_coarse, k=1)

    max_dist = spot_spacing * 0.6
    valid = distances < max_dist
    if not np.any(valid):
        return np.empty((0, 2), dtype=np.float64), np.empty((0, 2), dtype=np.float64)

    matched_off = pts_off[valid]
    matched_on = pts_on[indices[valid]]
    matched_dist = distances[valid]
    matched_indices = indices[valid]

                                 
    best = {}
    for i, idx_on in enumerate(matched_indices):
        if idx_on not in best or matched_dist[i] < matched_dist[best[idx_on]]:
            best[idx_on] = i

    if not best:
        return np.empty((0, 2), dtype=np.float64), np.empty((0, 2), dtype=np.float64)

    selected = sorted(best.values())
    return matched_on[selected], matched_off[selected]


def _estimate_similarity_transform(
    src: np.ndarray,
    dst: np.ndarray,
) -> np.ndarray:
    """
    Umeyama 算法估计 Similarity Transform（旋转+等比缩放+平移）。
    返回 2×3 矩阵 M，使得 dst ≈ M[:, :2] @ src.T + M[:, 2]。
    """
    assert src.shape == dst.shape
    assert src.shape[0] >= 2

    N = src.shape[0]
    mean_src = src.mean(axis=0)
    mean_dst = dst.mean(axis=0)

    src_demean = src - mean_src
    dst_demean = dst - mean_dst

    sigma = (dst_demean.T @ src_demean) / N
    U, S, Vt = np.linalg.svd(sigma)

    D = np.eye(2)
    D[-1, -1] = np.sign(np.linalg.det(U) * np.linalg.det(Vt))

    R = U @ D @ Vt
    scale = np.trace(np.diag(S) @ D) / (np.sum(src_demean ** 2) / N)
    t = mean_dst - scale * R @ mean_src

    M = np.hstack([scale * R, t.reshape(2, 1)])
    return M


def _warp_affine(
    image: np.ndarray,
    M: np.ndarray,
    shape: Tuple[int, ...],
) -> np.ndarray:
    """
    使用 scipy.ndimage.map_coordinates 对图像做仿射/相似变换。
    M 满足 p_aligned = M[:, :2] @ p_source + M[:, 2]，
    其中 p 为 (x, y) 坐标（对应图像的列、行）。
    """
    A = M[:, :2]
    b = M[:, 2]
    A_inv = np.linalg.inv(A)
    offset = -A_inv @ b

    y_coords, x_coords = np.mgrid[0:shape[0], 0:shape[1]]
                                 
    dst_xy = np.stack([x_coords.ravel(), y_coords.ravel()], axis=0).astype(np.float64)
                         
    with np.errstate(divide="ignore", over="ignore", invalid="ignore"):
        src_xy = A_inv.astype(np.float64) @ dst_xy + offset.astype(np.float64)[:, np.newaxis]
                                                   
    coords = src_xy[[1, 0], :].reshape(2, shape[0], shape[1])

    return ndimage.map_coordinates(
        image.astype(np.float64),
        coords,
        order=1,
        mode="constant",
        cval=0.0,
    )


def match_images_by_features(
    image_off: np.ndarray,
    image_on: np.ndarray,
    n_spots: Tuple[int, int],
    spot_spacing: float,
) -> np.ndarray:
    """
    基于特征匹配，对 image_off 进行几何变换，使其与 image_on 坐标系一致。

    Parameters
    ----------
    image_off : np.ndarray
        关闭时的图像
    image_on : np.ndarray
        开启时的图像（目标坐标系）
    n_spots : tuple(int, int)
        阵列行列数 (nx, ny)
    spot_spacing : float
        点近似间距，用于控制匹配容差

    Returns
    -------
    np.ndarray
        经特征匹配变换后的 image_off
    """
    nx, ny = n_spots if isinstance(n_spots, tuple) else (n_spots, n_spots)
    expected_n = nx * ny * 2

    pts_on = _extract_keypoints(image_on, expected_n, spot_spacing)
    pts_off = _extract_keypoints(image_off, expected_n, spot_spacing)

    if len(pts_on) < 2 or len(pts_off) < 2:
        Logger.warning(
            "Not enough keypoints for feature matching (%d on, %d off), returning original image_off",
            len(pts_on), len(pts_off),
        )
        return image_off.copy()

    matched_on, matched_off = _match_keypoints(pts_on, pts_off, spot_spacing)
    if len(matched_on) < 2:
        Logger.warning(
            "Not enough matched keypoints for feature matching (%d pairs), returning original image_off",
            len(matched_on),
        )
        return image_off.copy()

    M = _estimate_similarity_transform(matched_off, matched_on)
    corrected = _warp_affine(image_off, M, image_on.shape)
    Logger.info(
        "Feature matching succeeded with %d matched keypoints. Scale=%.4f",
        len(matched_on), np.linalg.norm(M[:, 0]),
    )
    return corrected
