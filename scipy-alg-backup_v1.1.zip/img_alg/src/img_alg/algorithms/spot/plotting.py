"""
SpotSpot 业务绘图模块
负责斑点分析相关的可视化与报告生成
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, Optional

from ...core.functions.erf import BilateralRect, RisingEdge, FallingEdge
from ...core.functions.gaussian import Gaussian, SuperGaussian, HyperbolicCosine
from ...utils import save_figure
from ...visualization.plotting import create_subplots_grid

_MODEL_FUNCTIONS = {
    'bilateral_erf': (BilateralRect.calculate1d_static, BilateralRect._param_order),
    'unilateral_rising_erf': (RisingEdge.calculate1d_static, RisingEdge._param_order),
    'unilateral_falling_erf': (FallingEdge.calculate1d_static, FallingEdge._param_order),
    'gaussian': (Gaussian.calculate1d_static, Gaussian._param_order),
    'super_gaussian': (SuperGaussian.calculate1d_static, SuperGaussian._param_order),
    'hyperbolic_cosine': (HyperbolicCosine.calculate1d_static, HyperbolicCosine._param_order),
}


class SpotSpotPlotter:
    """斑点分析结果绘图器"""

    def __init__(self, config: dict):
        """
        初始化绘图器

        Args:
            config: 可视化配置字典
        """
        self.config = config
        self.colormap = config.get('colormap', 'YlGnBu')
        self.dpi = config.get('image_dpi', 150)
        self.save_fitting_plots = config.get('save_fitting_plots', False)

    def plot_2d_heatmap(self,
                        data: np.ndarray,
                        center_x: float,
                        center_y: float,
                        output_path: str = None) -> None:
        """
        绘制2D热图

        Args:
            data: 数据
            center_x: 中心X坐标
            center_y: 中心Y坐标
            output_path: 输出路径
        """
        fig, ax = plt.subplots(figsize=(10, 8))

              
        im = ax.imshow(data, cmap=self.colormap, origin='upper')

                
        ax.plot(center_x, center_y, 'r+', markersize=15, markeredgewidth=2)

                 
        ax.set_title('2D Spot Intensity Heatmap')
        ax.set_xlabel('X Pixel')
        ax.set_ylabel('Y Pixel')

               
        plt.colorbar(im, ax=ax, label='Intensity')

               
        if output_path:
            save_figure(fig, output_path, dpi=self.dpi)
        else:
            plt.show()
            plt.close(fig)

    def plot_fitting_results(self,
                             results: Dict,
                             direction: str = 'all',
                             output_path: str = None) -> None:
        """
        绘制拟合结果

        Args:
            results: 分析结果
            direction: 方向
            output_path: 输出路径
        """
        if direction == 'all':
            directions = list(results.keys())
        else:
            directions = [direction]

        num_dirs = len(directions)
        fig, axes = create_subplots_grid(num_dirs, max_cols=3, figsize_per_plot=(6, 4))

        for idx, dir_key in enumerate(directions):
            ax = axes[idx]
            result = results[dir_key]

                         
            angles = result['angles']
            line_data = np.array(result['original_data'])
            x_data = np.arange(len(line_data))

            ax.plot(x_data, line_data, 'bo', alpha=0.7, label='Original Data')

            fit_params = result['fit_params']
            if fit_params['model_type'] != 'failed':
                model_entry = _MODEL_FUNCTIONS.get(fit_params['model_type'])
                if model_entry is not None and 'popt' in fit_params:
                    model_func, params_order = model_entry
                    kwargs = dict(zip(params_order, fit_params['popt']))
                    y_fit = model_func(x_data, **kwargs)
                    ax.plot(x_data, y_fit, 'r-', linewidth=2, label='Fitted Curve')

                        
                param_text = f"R={fit_params['R']:.2f}\n"
                param_text += f"k={fit_params['k']:.2f}\n"
                param_text += f"x0={fit_params['x0']:.2f}\n"
                param_text += f"R^2={fit_params['r_squared']:.3f}"

                ax.text(0.05, 0.95, param_text,
                        transform=ax.transAxes,
                        verticalalignment='top',
                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

                    
            angle_str = ','.join([str(int(a)) for a in angles])
            ax.set_title(f'Direction {angle_str} deg')
            ax.set_xlabel('Pixel Position')
            ax.set_ylabel('Intensity')
            ax.legend()
            ax.grid(True, alpha=0.3)

        plt.tight_layout()

        if output_path and self.save_fitting_plots:
            save_figure(fig, output_path, dpi=self.dpi)
        else:
            plt.show()
            plt.close(fig)

    def plot_comprehensive_results(self,
                                   data: np.ndarray,
                                   center_x: float,
                                   center_y: float,
                                   edge_analysis_results: Dict,
                                   output_dir: str) -> None:
        """
        绘制综合结果（包含热图和拟合图）

        Args:
            data: 原始数据
            center_x: 中心X坐标
            center_y: 中心Y坐标
            edge_analysis_results: 边缘分析结果
            output_dir: 输出目录
        """
        os.makedirs(output_dir, exist_ok=True)

                   
        heatmap_path = os.path.join(output_dir, 'spot_heatmap.png')
        self.plot_2d_heatmap(data, center_x, center_y, heatmap_path)

                   
        fitting_dir = os.path.join(output_dir, 'fitting_plots')
        os.makedirs(fitting_dir, exist_ok=True)

                    
        for direction in edge_analysis_results.keys():
            fitting_path = os.path.join(fitting_dir, f'fitting_{direction}.png')
            self.plot_fitting_results(edge_analysis_results, direction, fitting_path)

                         
        all_fitting_path = os.path.join(fitting_dir, 'all_directions_fitting.png')
        self.plot_fitting_results(edge_analysis_results, 'all', all_fitting_path)

    def save_summary_report(self,
                            analysis_results: Dict,
                            output_path: str) -> None:
        """
        保存分析报告

        Args:
            analysis_results: 分析结果
            output_path: 输出路径
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("Image Analysis System - Report\n")
            f.write("=" * 50 + "\n\n")

                      
            if 'center' in analysis_results:
                center = analysis_results['center']
                f.write(f"Spot Center:\n")
                f.write(f"  X: {center[0]:.3f} px\n")
                f.write(f"  Y: {center[1]:.3f} px\n\n")

                      
            if 'edge_analysis' in analysis_results:
                f.write("Edge Blur Analysis Results:\n")
                f.write("-" * 30 + "\n")

                edge_results = analysis_results['edge_analysis']
                for direction, result in edge_results.items():
                    fit_params = result['fit_params']
                    f.write(f"\nDirection {direction}:\n")
                    f.write(f"  Model Type: {fit_params['model_type']}\n")
                    f.write(f"  Goodness of Fit R²: {fit_params['r_squared']:.4f}\n")
                    f.write(f"  Spot Radius R: {fit_params['R']:.3f} px\n")
                    f.write(f"  Intensity Coefficient k: {fit_params['k']:.3f}\n")
                    f.write(f"  Background bg: {fit_params['bg']:.3f}\n")

                    if 'error' not in fit_params:
                        f.write(f"  Center Position x0: {fit_params['x0']:.3f} px\n")
                        if fit_params['model_type'] == 'bilateral_erf':
                            f.write(f"  Left Width σ1: {fit_params['sigma1']:.3f}\n")
                            f.write(f"  Right Width σ2: {fit_params['sigma2']:.3f}\n")
                        else:
                            f.write(f"  Edge Width σ: {fit_params['sigma']:.3f}\n")

                f.write("\n" + "=" * 50 + "\n")
                f.write("Analysis completed\n")
