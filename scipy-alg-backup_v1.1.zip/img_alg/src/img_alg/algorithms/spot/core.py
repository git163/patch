"""
斑点分析算法实现
负责斑点中心定位和边缘模糊分析的具体算法
"""

import numpy as np
from typing import Tuple, Dict, List, Optional
from ...models import (
    BilateralRectEstimator,
    RisingEdgeEstimator,
    FallingEdgeEstimator,
    GaussianEstimator,
    SuperGaussianEstimator,
    HyperbolicCosineEstimator,
)
from ...core.functions.erf import BilateralRect
from .center import center_of_mass
from ..common.geometry import extract_lines_through_center
from ..common.signal import calculate_snr, detect_signal_type
from ...utils import Logger


_ESTIMATOR_MAP = {
    'bilateral_erf': BilateralRectEstimator,
    'unilateral_rising_erf': RisingEdgeEstimator,
    'unilateral_falling_erf': FallingEdgeEstimator,
    'gaussian': GaussianEstimator,
    'super_gaussian': SuperGaussianEstimator,
    'hyperbolic_cosine': HyperbolicCosineEstimator,
}


class SpotAlgorithm:
    """增强的斑点分析算法，带智能曲线拟合"""

    def __init__(self):
        """初始化分析器"""
        self.results = {}

    def analyze_center(self,
                      data: np.ndarray,
                      method: str = 'auto',
                      num_lines: int = 3,
                      line_max_interval: int = 5,
                      ) -> Tuple[float, float]:
        """
        斑点中心定位

        Args:
            data: 输入数据
            method: 定位方法 ('auto', 'centroid', 'profile')

        Returns:
            tuple: (x_center, y_center)
        """
        if method == 'auto':
                         
            snr = calculate_snr(data)
            method = 'centroid' if snr > 3 else 'profile'

        if method == 'centroid':
            return center_of_mass(data)
        elif method == 'profile':
            return self._profile_method(data, num_lines=num_lines, line_max_interval=line_max_interval)
        else:
            raise ValueError(f"Unsupported localization method: {method}")

    def _profile_method(self,
                       data: np.ndarray,
                       num_lines: int,
                       line_max_interval: int) -> Tuple[float, float]:
        """剖面法精确定位"""
        x_init, y_init = center_of_mass(data)
        m = line_max_interval / num_lines if num_lines > 0 else line_max_interval

        x_positions = self._sample_axis(data, num_lines, m, y_init, axis=0, default=x_init)
        y_positions = self._sample_axis(data, num_lines, m, x_init, axis=1, default=y_init)

        x_final = np.mean(x_positions) if x_positions else x_init
        y_final = np.mean(y_positions) if y_positions else y_init
        return float(x_final), float(y_final)

    def _sample_axis(self,
                     data: np.ndarray,
                     num_lines: int,
                     interval: float,
                     center_pos: float,
                     axis: int,
                     default: float) -> List[float]:
        """沿指定轴采样并拟合中心位置。axis=0 为水平方向，axis=1 为垂直方向。"""
        positions = []
        size = data.shape[1 - axis]
        for j in range(1, num_lines + 1):
            pos = center_pos + (j - num_lines / 2.0) * interval
            idx = int(np.clip(np.round(pos), 0, size - 1))
            if 0 <= idx < size:
                line_data = data[idx, :] if axis == 0 else data[:, idx]
                if len(line_data) > 0:
                    center = self._fit_1d_profile(np.arange(len(line_data)), line_data).get('center', default)
                    positions.append(center)
        return positions

    def analyze_edge_blur(self,
                         data: np.ndarray,
                         center_x: float,
                         center_y: float,
                         directions: List[str] = None) -> Dict:
        """
        边缘模糊分析

        Args:
            data: 输入数据
            center_x: 中心X坐标
            center_y: 中心Y坐标
            directions: 分析方向列表

        Returns:
            分析结果字典
        """
        if directions is None:
            directions = ['0', '45', '90', '135']

        results = {}
        for direction in directions:
            line_data, angles = extract_lines_through_center(data, center_x, center_y, direction)
            fit_params = self._fit_1d_profile(np.arange(len(line_data)), line_data)
            results[direction] = {
                'line_data': line_data.tolist(),
                'angles': angles.tolist() if isinstance(angles, np.ndarray) else angles,
                'fit_params': fit_params,
                'original_data': line_data.tolist()
            }
        return results

    def _fit_1d_profile(self, x_data: np.ndarray, y_data: np.ndarray):
        """
        增强版1D轮廓拟合

        Args:
            x_data: 输入X数据
            y_data: 输入Y数据

        Returns:
            dict: 拟合结果字典（保持与旧版兼容的格式）
        """
        x_fit = x_data
        y_fit = y_data

                     
        function_type = detect_signal_type(x_fit, y_fit)
        estimator_cls = _ESTIMATOR_MAP.get(function_type, BilateralRectEstimator)
        estimator = estimator_cls()

        try:
            estimator.fit(x_fit, y_fit)
            return self._record_fit_quality(y_fit, estimator, function_type)
        except Exception as e:
            Logger.error("Fitting failed: %s", e)
            return self._fit_failure_result()

    @staticmethod
    def _get_param_index(estimator, param_name: str) -> int:
        """获取参数在 popt 中的索引。"""
        if param_name in ['x0', 'cx']:
            for name in ['cx', 'x0']:
                if name in estimator.params_order_:
                    return estimator.params_order_.index(name)
        try:
            return estimator.params_order_.index(param_name)
        except ValueError:
            raise ValueError(f"Parameter '{param_name}' is not in params_order")

    @staticmethod
    def _fit_failure_result() -> Dict:
        return {'error': 'fitting_failed', 'model_type': 'failed'}

    def _record_fit_quality(self, original_data, estimator, function_type: str) -> Dict:
        """记录拟合质量指标（保持与旧版兼容的格式）"""
        if not estimator.success_:
            return self._fit_failure_result()

        center = float(estimator.center_) if estimator.center_ is not None else 0.0
        fit_info = {
            'r_squared': float(estimator.diagnostics_['r_squared']),
            'success': estimator.success_,
            'center': center,
            'popt': estimator.popt_.tolist() if hasattr(estimator.popt_, 'tolist') else list(estimator.popt_),
            'params_order': list(estimator.params_order_),
            'model_type': function_type,
            'parameters': {k: float(v) for k, v in estimator.params_.items()},
        }

                                           
        for key in ['R', 'k', 'x0', 'bg', 'sigma1', 'sigma2', 'sigma', 'amplitude', 'n', 'width']:
            if key in estimator.params_:
                fit_info[key] = float(estimator.params_[key])

        return fit_info
