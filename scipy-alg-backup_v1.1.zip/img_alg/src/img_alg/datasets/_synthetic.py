"""
仿真数据生成接口（sklearn.datasets 风格）。
"""

import os

import numpy as np
from PIL import Image

from ..utils import save_array_csv, ensure_dir

from ..core.functions.erf import BilateralRect, RisingEdge, FallingEdge
from ..core.functions.gaussian import Gaussian, SuperGaussian, HyperbolicCosine
from ..core.functions.distortion import (
    RadialDistortion,
    TangentialDistortion,
    SineWaveDistortion,
    PerspectiveDistortion,
)

_MATHFUNC_MAP = {
    'bilateral_rect': BilateralRect,
    'rising_edge': RisingEdge,
    'falling_edge': FallingEdge,
    'gaussian': Gaussian,
    'super_gaussian': SuperGaussian,
    'hyperbolic_cosine': HyperbolicCosine,
}

_DISTORTION_MAP = {
    'radial': RadialDistortion,
    'tangential': TangentialDistortion,
    'sine_wave': SineWaveDistortion,
    'perspective': PerspectiveDistortion,
}


def make_spot(model='bilateral_rect', image_size=256, noise_level=0.0, output_path=None, **model_params):
    """
    生成 2D 点仿真图像。

    Parameters
    ----------
    model : str
        模型类型：'bilateral_rect', 'rising_edge', 'falling_edge',
        'gaussian', 'super_gaussian', 'hyperbolic_cosine'
    image_size : int
        图像尺寸（生成 image_size × image_size 的图像）
    noise_level : float
        高斯噪声标准差
    output_path : str or None
        输出 CSV 文件路径。如果不为 None，将 2D 数据保存为 CSV 文件，
        列名为 Current，每行一个数据。如果目录不存在会自动创建。
    **model_params
        传递给对应 FittingFunction 构造函数的参数

    Returns
    -------
    np.ndarray
        2D 仿真图像
    """
    if model not in _MATHFUNC_MAP:
        available = list(_MATHFUNC_MAP.keys())
        raise ValueError(f"Unsupported model type: {model}. Available types: {available}")

    cls = _MATHFUNC_MAP[model]
    func = cls(**model_params)

    y_indices, x_indices = np.mgrid[0:image_size, 0:image_size]
    img = func.calculate2d(x_indices, y_indices)

    if noise_level > 0:
        if model in ['gaussian', 'super_gaussian', 'hyperbolic_cosine']:
            noise_level = noise_level * 0.01          
        img = img + np.random.normal(0, noise_level, img.shape)

    if output_path is not None:
        save_array_csv(img.reshape(-1, 1), output_path, header='Current', delimiter=',', fmt='%.6f')

    return img


def make_profile(model='bilateral_rect', n_samples=256, noise_level=0.0, **model_params):
    """
    生成 1D 点轮廓（line profile）仿真数据。

    Parameters
    ----------
    model : str
        模型类型：'bilateral_rect', 'rising_edge', 'falling_edge',
        'gaussian', 'super_gaussian', 'hyperbolic_cosine'
    n_samples : int
        采样点数
    noise_level : float
        高斯噪声标准差
    **model_params
        传递给对应 FittingFunction 构造函数的参数

    Returns
    -------
    x : np.ndarray
        1D 坐标数组（.linspace(0, n_samples-1, n_samples)）
    y : np.ndarray
        1D 仿真信号（含可选噪声）
    """
    if model not in _MATHFUNC_MAP:
        available = list(_MATHFUNC_MAP.keys())
        raise ValueError(f"Unsupported model type: {model}. Available types: {available}")

    cls = _MATHFUNC_MAP[model]
    func = cls(**model_params)

    x = np.linspace(0, n_samples - 1, n_samples)
    y = func.calculate1d(x)

    if noise_level > 0:
        y = y + np.random.normal(0, noise_level, y.shape)

    return x, y


def make_spot_lattice(
    image_size=256,
    n_spots=3,
    spot_spacing=50.0,
    amplitude=1.0,
    sigma=10.0,
    rotation=0.0,
    translation=(0.0, 0.0),
    scale=1.0,
    distortion=None,
    noise_level=0.0,
    output_path=None,
    spot_mask=None,
):
    """
    生成高斯阵列列仿真图像。

    Parameters
    ----------
    image_size : int
        图像尺寸（生成 image_size × image_size 的图像）
    n_spots : int or tuple(int, int)
        阵列个数。若为整数，生成 n_spots × n_spots 的阵列；
        若为二元组，生成 (nx, ny) 的阵列。
    spot_spacing : float
        相邻点中心之间的距离（像素）
    amplitude : float
        每个高斯点的峰值强度
    sigma : float
        每个高斯点的标准差
    rotation : float
        旋转角度（度），绕阵列中心旋转
    translation : tuple(float, float)
        (tx, ty) 平移偏移（像素）
    scale : float or tuple(float, float)
        阵列缩放因子。数值表示等比例缩放，元组表示 (sx, sy)。
    distortion : dict or None
        变形参数，支持四种类型：
        - 径向变形：{'type': 'radial', 'k1': 1e-4, 'k2': 0.0}
          公式：x' = x * (1 + k1*r^2 + k2*r^4), y' = y * (1 + k1*r^2 + k2*r^4)
        - 切向变形：{'type': 'tangential', 'p1': 0.1, 'p2': 0.1}
        - 正弦波浪变形：{'type': 'sine_wave', 'amplitude': 0.15, 'frequency': 2.0}
        - 透视变形：{'type': 'perspective', 'shear_x': 0.15, 'shear_y': 0.1}
        若未指定 type 但包含 k1，则默认当作 radial 处理。
    noise_level : float
        高斯白噪声标准差
    output_path : str or None
        TIFF 图像保存路径。若不为 None，保存为 .tif 图像。
    spot_mask : array-like or None
        每个点的亮度乘子（multiplier）。
        - 若为 1D，长度须为 nx * ny，顺序与 meshgrid 展平后的 C-order 一致（行优先）。
        - 若为 2D，形状须为 (ny, nx)，对应视觉网格的行数 × 列数。
        例如 ``0.0`` 表示该点不亮，``0.2`` 表示亮度降至 20%%。

    Returns
    -------
    np.ndarray
        2D 仿真图像
    """
                
    if isinstance(n_spots, int):
        nx = ny = n_spots
    else:
        nx, ny = n_spots

              
    if isinstance(scale, (int, float)):
        sx = sy = float(scale)
    else:
        sx, sy = scale

                     
    x_grid = np.arange(nx) * spot_spacing
    y_grid = np.arange(ny) * spot_spacing
    x_grid = x_grid - x_grid.mean()
    y_grid = y_grid - y_grid.mean()
    xx, yy = np.meshgrid(x_grid, y_grid)
    centers = np.stack([xx.ravel(), yy.ravel()], axis=1)          

        
    centers[:, 0] *= sx
    centers[:, 1] *= sy

        
    theta = np.deg2rad(rotation)
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    rot_matrix = np.array([[cos_t, -sin_t], [sin_t, cos_t]])
    centers = centers @ rot_matrix.T

                    
    if distortion is not None:
        d_type = distortion.get('type', 'radial' if 'k1' in distortion else None)
        if d_type is None:
            raise ValueError("distortion parameter must contain 'type' or 'k1' field")
        if d_type not in _DISTORTION_MAP:
            available = list(_DISTORTION_MAP.keys())
            raise ValueError(f"Unsupported distortion type: {d_type}. Supported: {available}")

        cls = _DISTORTION_MAP[d_type]
        kwargs = {k: v for k, v in distortion.items() if k != 'type'}
        func = cls(**kwargs)
        X = centers[:, 0].copy()
        Y = centers[:, 1].copy()
        X, Y = func.distort(X, Y)
        centers[:, 0] = X
        centers[:, 1] = Y

                 
    tx, ty = translation
    centers[:, 0] += tx + image_size / 2.0
    centers[:, 1] += ty + image_size / 2.0

                  
    if spot_mask is not None:
        spot_mask = np.asarray(spot_mask, dtype=float)
        if spot_mask.ndim == 1:
            if spot_mask.size != nx * ny:
                raise ValueError(
                    f"spot_mask 1D length must be {nx * ny}, got {spot_mask.size}"
                )
            spot_factors = spot_mask
        elif spot_mask.ndim == 2:
            if spot_mask.shape != (ny, nx):
                raise ValueError(
                    f"spot_mask 2D shape must be {(ny, nx)}, got {spot_mask.shape}"
                )
            spot_factors = spot_mask.ravel()
        else:
            raise ValueError(
                f"spot_mask must be 1D or 2D, got {spot_mask.ndim}D"
            )
    else:
        spot_factors = np.ones(nx * ny, dtype=float)

            
    y_indices, x_indices = np.mgrid[0:image_size, 0:image_size]

                          
                                  
    dx = x_indices[..., np.newaxis] - centers[:, 0]
    dy = y_indices[..., np.newaxis] - centers[:, 1]
    r2 = dx ** 2 + dy ** 2
    img = np.sum(amplitude * spot_factors * np.exp(-r2 / (2.0 * sigma ** 2)), axis=2)

          
    if noise_level > 0:
        img = img + np.random.normal(0, noise_level, img.shape)

          
    if output_path is not None:
        ensure_dir(output_path)
                                        
        img_min = img.min()
        img_max = img.max()
        denom = img_max - img_min if img_max != img_min else 1.0
        img_uint8 = ((img - img_min) / denom * 255).astype(np.uint8)
        Image.fromarray(img_uint8).save(output_path, format='TIFF')

    return img
