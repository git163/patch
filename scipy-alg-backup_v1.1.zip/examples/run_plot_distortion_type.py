import os
import sys

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_PROJECT_ROOT, "img_alg", "src"))

import img_alg.visualization                          

import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch
from matplotlib.transforms import Affine2D
import matplotlib.patches as patches

OUTPUT_DIR = os.path.join(_PROJECT_ROOT, "data", "image", "simulation", "distortion_types")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def _show_or_save(fig, name):
    """非 Agg 后端时显示，否则保存到文件。"""
    if matplotlib.get_backend().lower() == "agg":
        path = os.path.join(OUTPUT_DIR, name)
        fig.savefig(path, dpi=150, bbox_inches="tight")
        print(f"Saved: {path}")
    plt.close(fig)

def create_grid(ax, x_range=(-2, 2), y_range=(-2, 2), step=0.2, color='gray', alpha=0.6, linewidth=0.8):
    """创建基础网格"""
    x = np.arange(x_range[0], x_range[1] + step, step)
    y = np.arange(y_range[0], y_range[1] + step, step)
    X, Y = np.meshgrid(x, y)
    
           
    for i in range(len(x)):
        ax.plot([x[i], x[i]], [y_range[0], y_range[1]], color=color, alpha=alpha, linewidth=linewidth)
    for i in range(len(y)):
        ax.plot([x_range[0], x_range[1]], [y[i], y[i]], color=color, alpha=alpha, linewidth=linewidth)
    
           
    ax.scatter([0], [0], color='red', s=50, zorder=5, label='图像中心')
    
    return X, Y

def plot_distorted(ax, title, distortion_func, x_range=(-2, 2), y_range=(-2, 2), step=0.2):
    """绘制后的网格"""
    x = np.arange(x_range[0], x_range[1] + step, step)
    y = np.arange(y_range[0], y_range[1] + step, step)
    X, Y = np.meshgrid(x, y)
    
          
    X_distorted, Y_distorted = distortion_func(X, Y)
    
              
    for i in range(len(x)):
        ax.plot(X_distorted[i, :], Y_distorted[i, :], 'b-', alpha=0.6, linewidth=0.8)
    for j in range(len(y)):
        ax.plot(X_distorted[:, j], Y_distorted[:, j], 'b-', alpha=0.6, linewidth=0.8)
    
           
    center_x, center_y = distortion_func(np.array([0]), np.array([0]))
    ax.scatter(center_x, center_y, color='red', s=80, zorder=5, edgecolors='darkred', linewidths=2)
    
    ax.set_title(title, fontsize=12, fontweight='bold')
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.2)
    ax.axhline(y=0, color='black', alpha=0.3, linewidth=0.5)
    ax.axvline(x=0, color='black', alpha=0.3, linewidth=0.5)

                                                          
def radial_distortion(X, Y, k1=0.3, k2=0.0, type='barrel'):
    """径向"""
    r2 = X**2 + Y**2
    if type == 'barrel':
                         
        k1_actual = -0.25
    else:
                         
        k1_actual = 0.25
    
    r_factor = 1 + k1_actual * r2
    return X * r_factor, Y * r_factor

                                                          
def tangential_distortion(X, Y, p1=0.1, p2=0.1):
    """切向 - 由镜头与图像平面不平行导致"""
    r2 = X**2 + Y**2
    X_distorted = X + 2 * p1 * X * Y + p2 * (r2 + 2 * X**2)
    Y_distorted = Y + p1 * (r2 + 2 * Y**2) + 2 * p2 * X * Y
    return X_distorted, Y_distorted

                                                     
def sine_wave_distortion(X, Y, amplitude=0.15, frequency=2.0):
    """正弦波浪 - 周期性扭曲"""
    X_distorted = X + amplitude * np.sin(frequency * Y * np.pi)
    Y_distorted = Y + amplitude * np.sin(frequency * X * np.pi)
    return X_distorted, Y_distorted

                                                   
def perspective_distortion(X, Y, shear_x=0.15, shear_y=0.1):
    """透视 - 模拟倾斜视角"""
                 
    X_distorted = X + shear_x * Y
    Y_distorted = Y + shear_y * X
    return X_distorted, Y_distorted

                                                     
def create_dot_grid(ax, distortion_func=None, title="原始阵列", show_distorted=True):
    """绘制阵列效果"""
            
    x = np.arange(-2, 2.1, 0.4)
    y = np.arange(-2, 2.1, 0.4)
    X, Y = np.meshgrid(x, y)
    
    if show_distorted and distortion_func:
        X_plot, Y_plot = distortion_func(X, Y)
        title = title
    else:
        X_plot, Y_plot = X, Y
    
    ax.scatter(X_plot.flatten(), Y_plot.flatten(), c='blue', s=30, alpha=0.7, zorder=2)
    
                 
    if show_distorted and distortion_func:
                        
        for i in range(X.shape[0]):
            for j in range(X.shape[1]):
                if abs(X[i,j]) < 1.8 and abs(Y[i,j]) < 1.8:
                    ax.arrow(X[i,j], Y[i,j], 
                            X_plot[i,j] - X[i,j], Y_plot[i,j] - Y[i,j],
                            head_width=0.03, head_length=0.05, fc='red', ec='red', alpha=0.4, length_includes_head=True)
    
    ax.scatter([0], [0], color='red', s=60, zorder=5, edgecolors='darkred', linewidths=2)
    ax.set_title(title, fontsize=11, fontweight='bold')
    ax.set_aspect('equal')
    ax.set_xlim(-2.5, 2.5)
    ax.set_ylim(-2.5, 2.5)
    ax.grid(True, alpha=0.3)

                                                
fig = plt.figure(figsize=(14, 8))

              
ax1 = fig.add_subplot(2, 3, 1)
plot_distorted(ax1, "① 径向 - 桶形 (Barrel)", 
               lambda X, Y: radial_distortion(X, Y, type='barrel'))

              
ax2 = fig.add_subplot(2, 3, 2)
plot_distorted(ax2, "② 径向 - 枕形 (Pincushion)", 
               lambda X, Y: radial_distortion(X, Y, type='pincushion'))

                 
ax3 = fig.add_subplot(2, 3, 3)
plot_distorted(ax3, "③ 切向 (Tangential Distortion)\np₁=0.1, p₂=0.1", 
               tangential_distortion)

           
ax4 = fig.add_subplot(2, 3, 4)
plot_distorted(ax4, "④ 正弦波浪 (Sine Wave Distortion)\n振幅=0.15, 频率=2.0", 
               sine_wave_distortion)

         
ax5 = fig.add_subplot(2, 3, 5)
plot_distorted(ax5, "⑤ 透视 (Perspective Distortion)\n剪切: x=0.15, y=0.1", 
               perspective_distortion)

                    
ax6 = fig.add_subplot(2, 3, 6)
create_dot_grid(ax6, tangential_distortion, "阵列示例 - 切向 (带位移矢量)")

plt.suptitle("常见图像类型可视化", fontsize=16, fontweight='bold', y=0.98)
plt.tight_layout()
_show_or_save(fig, "distortion_types_overview.png")

                                                      
fig2, axes = plt.subplots(2, 2, figsize=(12, 8))

          
def show_radial_params(ax, k1_values):
    x = np.arange(-2, 2.05, 0.1)
    y = np.zeros_like(x)
    for k1 in k1_values:
        r2 = x**2
        r_factor = 1 + k1 * r2
        x_distorted = x * r_factor
        ax.plot(x, x_distorted - x, label=f'k₁ = {k1}', linewidth=2)
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.5)
    ax.set_xlabel('原始位置 r', fontsize=10)
    ax.set_ylabel('径向位移 Δr', fontsize=10)
    ax.set_title('径向参数 k₁ 的影响\n(负值→桶形, 正值→枕形)', fontsize=11)
    ax.legend()
    ax.grid(True, alpha=0.3)

          
def show_tangential_params(ax):
                 
    X, Y = np.meshgrid(np.linspace(-2, 2, 20), np.linspace(-2, 2, 20))
    X_dist, Y_dist = tangential_distortion(X, Y, p1=0.08, p2=0.08)
    
             
    ax.quiver(X, Y, X_dist - X, Y_dist - Y, alpha=0.6, scale=8, width=0.008)
    ax.scatter([0], [0], color='red', s=50, zorder=5)
    ax.set_title('切向位移矢量场\n(p₁=0.08, p₂=0.08)', fontsize=11)
    ax.set_aspect('equal')
    ax.set_xlim(-2.2, 2.2)
    ax.set_ylim(-2.2, 2.2)
    ax.grid(True, alpha=0.3)

          
def show_sine_params(ax):
    X = np.linspace(-2, 2, 100)
    for amp in [0.05, 0.1, 0.15, 0.2]:
        Y = amp * np.sin(2 * np.pi * X)
        ax.plot(X, Y, label=f'振幅 = {amp}', linewidth=1.5)
    ax.set_xlabel('X 位置', fontsize=10)
    ax.set_ylabel('Y 方向位移', fontsize=10)
    ax.set_title('正弦波浪 - 不同振幅的影响', fontsize=11)
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.3)

        
def show_perspective_example(ax):
                      
    rect = Rectangle((-1, -0.8), 2, 1.6, linewidth=2, edgecolor='blue', facecolor='lightblue', alpha=0.5)
    ax.add_patch(rect)
    
               
            
    pts = np.array([[-1, -0.8], [1, -0.8], [1.2, 0.8], [-0.8, 0.8]])
    poly = patches.Polygon(pts, linewidth=2, edgecolor='red', facecolor='lightcoral', alpha=0.5, label='透视后')
    ax.add_patch(poly)
    
    ax.set_xlim(-1.5, 1.5)
    ax.set_ylim(-1.2, 1.2)
    ax.set_title('透视 - 矩形变换示意\n(蓝色:原始, 红色:后)', fontsize=11)
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    ax.legend()

show_radial_params(axes[0, 0], [-0.25, -0.1, 0, 0.1, 0.25])
show_tangential_params(axes[0, 1])
show_sine_params(axes[1, 0])
show_perspective_example(axes[1, 1])

plt.suptitle("参数详解与影响分析", fontsize=14, fontweight='bold')
plt.tight_layout()
_show_or_save(fig2, "distortion_params_detail.png")

                                                
print("\n" + "="*70)
print("数学模型公式")
print("="*70)

print("\n【径向 Radial Distortion】")
print("  x_distorted = x * (1 + k₁·r² + k₂·r⁴ + k₃·r⁶)")
print("  y_distorted = y * (1 + k₁·r² + k₂·r⁴ + k₃·r⁶)")
print("  其中 r² = x² + y²")
print("  • k₁ < 0: 桶形 (Barrel)")
print("  • k₁ > 0: 枕形 (Pincushion)")

print("\n【切向 Tangential Distortion】")
print("  x_distorted = x + 2·p₁·x·y + p₂·(r² + 2x²)")
print("  y_distorted = y + p₁·(r² + 2y²) + 2·p₂·x·y")
print("  • p₁, p₂: 切向系数")
print("  • 主要由镜头与图像平面不平行引起")

print("\n【正弦波浪 Sine Wave Distortion】")
print("  x_distorted = x + A·sin(2π·f·y)")
print("  y_distorted = y + A·sin(2π·f·x)")
print("  • A: 振幅 (Amplitude)")
print("  • f: 频率 (Frequency)")

print("\n【透视 Perspective Distortion】")
print("  透视通常用单应性矩阵 H 描述：")
print("  [x']   [h₁₁ h₁₂ h₁₃] [x]")
print("  [y'] = [h₂₁ h₂₂ h₂₃] [y]")
print("  [w']   [h₃₁ h₃₂  1 ] [1]")
print("  最终坐标: (x'/w', y'/w')")
print("  • 主要由倾斜角度引起")
print("  • 导致近大远小、形状扭曲")

print("\n" + "="*70)