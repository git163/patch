import os
import sys

                        
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_PROJECT_ROOT, 'img_alg', 'src'))

import numpy as np
from scipy import ndimage

from img_alg.datasets import make_spot_lattice
from img_alg.algorithms import AnalyzerFactory, LatticeAnomalyAnalyzer

OUTPUT_DIR = "data/image/simulation/lattice_anomaly"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def apply_transform(image, scale=1.0, angle_deg=0.0, tx=0.0, ty=0.0):
    """对图像施加相似变换（旋转+缩放+平移），模拟装夹偏差。"""
    theta = np.deg2rad(angle_deg)
    cos_t, sin_t = np.cos(theta), np.sin(theta)
    R = np.array([[cos_t, -sin_t], [sin_t, cos_t]])
    A_inv = (1.0 / scale) * R.T
    t = np.array([tx, ty])
    offset = -A_inv @ t
    return ndimage.affine_transform(
        image,
        matrix=A_inv,
        offset=offset,
        output_shape=image.shape,
        order=1,
        mode="constant",
        cval=0.0,
    )


def build_simulation_pair():
    """构造 simulation 模式的 on/off 图像对。"""
    image_size = 1024
    n_spots = (5, 5)
    spot_spacing = 60.0
    sigma = 8.0
    noise_level = 0.02

                                     
    mask_on = np.ones((5, 5), dtype=float)
    mask_on[2, 0] = 0.15         
    mask_on[3, 2] = 0.15           
    params = {
        "name": "complex",
        "title": "complex distortion",
        "params": {
            "rotation": 15.0,
            "scale": (1.2, 0.8),
            "translation": (10.0, 20.0),
            "distortion": {"type": "radial", "k1": 5e-5, "k2": 0.0},
        },
    }
    data_on = make_spot_lattice(
        image_size=image_size,
        n_spots=n_spots,
        spot_spacing=spot_spacing,
        sigma=sigma,
        noise_level=noise_level,
        spot_mask=mask_on,
        **params["params"],
    )

                                 
    mask_off = np.zeros((5, 5), dtype=float)
    mask_off[0, 0] = 1.0
    mask_off[0, 4] = 1.0
    mask_off[4, 0] = 1.0
    mask_off[4, 4] = 1.0
    data_off = make_spot_lattice(
        image_size=image_size,
        n_spots=n_spots,
        spot_spacing=spot_spacing,
        sigma=sigma,
        noise_level=noise_level,
        spot_mask=mask_off,
        **params["params"],
    )

                                           

    return data_on, data_off, n_spots, spot_spacing


def main():
    data_on, data_off, n_spots, spot_spacing = build_simulation_pair()

    params = {
        "mode": "simulation",
        "data_on": data_on,
        "data_off": data_off,
        "n_spots": n_spots,
        "spot_spacing": spot_spacing,
        "diff_ratio_threshold": 2.0,
        "intensity_threshold": "median",
        "enable_feature_matching": True,
    }

                        
    import matplotlib.pyplot as plt
    plt.imsave(os.path.join(OUTPUT_DIR, "data_on.png"), data_on, cmap="gray")
    plt.imsave(os.path.join(OUTPUT_DIR, "data_off.png"), data_off, cmap="gray")
    print(f"Input images saved to {OUTPUT_DIR}")

    print("Running lattice anomaly detection...")
    analyzer = LatticeAnomalyAnalyzer()
    err, results = analyzer.process(params)

    if err == 0:
        assert isinstance(analyzer, LatticeAnomalyAnalyzer)

        output_path = os.path.join(OUTPUT_DIR, "lattice_anomaly_demo.png")
        analyzer.plot_results(results, output_path=output_path, title="Lattice Anomaly Detection Demo")
        print(f"Plot saved to: {output_path}")

        print(f"\nTotal candidate spots: {len(results.get('spot_centers', []))}")
        print(f"Always ON  ({len(results['always_on'])}):")
        for pt in results["always_on"]:
            print(f"  x={pt['x']:.2f}, y={pt['y']:.2f}, I_on={pt['I_on']:.4f}, I_off={pt['I_off']:.4f}, ratio={pt['ratio']:.4f}")
        print(f"Always OFF ({len(results['always_off'])}):")
        for pt in results["always_off"]:
            print(f"  x={pt['x']:.2f}, y={pt['y']:.2f}, I_on={pt['I_on']:.4f}, I_off={pt['I_off']:.4f}, ratio={pt['ratio']:.4f}")

              
        analyzer.save_results(results, output_dir=OUTPUT_DIR)
    else:
        print(f"Analysis failed with error code {err}, error={results.get('error') if results else None}")


if __name__ == "__main__":
    main()
