import os
import sys

                        
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_PROJECT_ROOT, 'img_alg', 'src'))

import numpy as np
from img_alg.datasets import make_spot_lattice
from img_alg.algorithms import AnalyzerFactory, SpotLatticeAnalyzer

OUTPUT_DIR = "data/image/simulation/lattice_analysis"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def run_simulation_demo():
    """simulation 模式：生成阵列并分析。"""
    configs = [
        {
            "name": "default",
            "title": "3x3 Default Lattice",
            "params": {},
        },
        {
            "name": "radial_distortion",
            "title": "Radial Distortion (k1=1e-4)",
            "params": {"distortion": {"type": "radial", "k1": 1e-4, "k2": 0.0}},
        },
        {
            "name": "small_radial_distortion",
            "title": "Small Radial Distortion (k1=5e-5)",
            "params": {"distortion": {"type": "radial", "k1": 5e-5, "k2": 0.0}},
        },
        {
            "name": "sine_wave_distortion",
            "title": "Sine Wave Distortion",
            "params": {"distortion": {"type": "sine_wave", "amplitude": 8.0, "frequency": 0.15}},
        },
        {
            "name": "perspective_distortion",
            "title": "Perspective Distortion",
            "params": {"distortion": {"type": "perspective", "shear_x": 0.15, "shear_y": 0.1}},
        },
        {
            "name": "rotation_scale_radial",
            "title": "Rotation+Scale+Radial",
            "params": {
                "rotation": 15.0,
                "scale": (1.2, 0.8),
                "distortion": {"type": "radial", "k1": 5e-5, "k2": 0.0},
            },
        },
    ]

    image_size = 1024
    n_spots = (4, 4)
    spot_spacing = 60.0

    for cfg in configs:
        params = dict(
            image_size=image_size,
            n_spots=n_spots,
            spot_spacing=spot_spacing,
            amplitude=1.0,
            sigma=8.0,
            noise_level=0.02,
        )
        params.update(cfg["params"])

        print(f"\n--- {cfg['title']} ---")
        params_with_mode = dict(mode="simulation", **params)
        err, results = AnalyzerFactory.run_task("lattice", params_with_mode)

        if err == 0:
            output_path = os.path.join(OUTPUT_DIR, f"lattice_{cfg['name']}_analysis.png")
                          
            analyzer = AnalyzerFactory.create("lattice")
            assert isinstance(analyzer, SpotLatticeAnalyzer)
            analyzer.plot_results(results, output_path=output_path, title=cfg["title"])
            print(f"Lattice center: {results['lattice_center']}")
            print(f"Edge centers: {results['edge_centers']}")
            print(f"Plot saved to: {output_path}")
        else:
            print(f"Analysis failed with error code {err}, error={results.get('error') if results else None}")


def run_real_mode_example():
    """real 模式示例（仅当存在本地图像文件时运行）。"""
    err, results = AnalyzerFactory.run_task("lattice", {
        "input_file": None,                                             
        "n_spots": (4, 4),
        "spot_spacing": 60.0,
        "mode": "real",
    })
    if err == 0:
        output_path = os.path.join(OUTPUT_DIR, "lattice_real_analysis.png")
        analyzer = AnalyzerFactory.create("lattice")
        assert isinstance(analyzer, SpotLatticeAnalyzer)
        analyzer.plot_results(results, output_path=output_path)
        print(f"\nReal mode analysis succeeded. Center: {results['lattice_center']}")
    elif err == 1:
        print("\nReal mode: no input file found, skipping real mode demo.")
    else:
        print(f"\nReal mode failed with error code {err}")


if __name__ == "__main__":
    run_simulation_demo()
                             
