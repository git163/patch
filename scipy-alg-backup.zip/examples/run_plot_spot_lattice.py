import os
import sys

                        
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_PROJECT_ROOT, 'img_alg', 'src'))

import numpy as np

from img_alg.datasets import make_spot_lattice
from img_alg.visualization.plotting import create_2d_plot

OUTPUT_DIR_PNG = "data/image/simulation/lattice_png"
OUTPUT_DIR_TIF = "data/image/simulation/lattice_tif"
os.makedirs(OUTPUT_DIR_PNG, exist_ok=True)
os.makedirs(OUTPUT_DIR_TIF, exist_ok=True)


def main():
    image_size = 1024

    configs = [
        {
            "name": "default",
            "title": "Default 3x3 Lattice",
            "params": {},
        },
        {
            "name": "distorted_radial",
            "title": "Radial Distortion (k1=1e-4)",
            "params": {"distortion": {"type": "radial", "k1": 1e-4, "k2": 0.0}},
        },
        {
            "name": "distorted_tangential",
            "title": "4x4 Tangential Distortion (p1=1, p2=1)",
            "params": {"n_spots": 4, "spot_spacing": 10.0, "distortion": {
                "type": "tangential", "p1": 0.2, "p2": 0.2}},
        },
        {
            "name": "distorted_sine",
            "title": "Sine Wave Distortion",
            "params": {"distortion": {"type": "sine_wave", "amplitude": 8.0, "frequency": 0.15}},
        },
        {
            "name": "distorted_perspective",
            "title": "Perspective Distortion",
            "params": {"distortion": {"type": "perspective", "shear_x": 0.15, "shear_y": 0.1}},
        },
        {
            "name": "rect_grid",
            "title": "2x4 Rectangular Lattice",
            "params": {"n_spots": (2, 4)},
        },
        {
            "name": "complex",
            "title": "Rotation+Scale+Distortion+Translation",
            "params": {
                "rotation": 15.0,
                "scale": (1.2, 0.8),
                "translation": (10.0, 20.0),
                "distortion": {"type": "radial", "k1": 5e-5, "k2": 0.0},
            },
        },
        {
            "name": "all_transforms",
            "title": "6x6 Scale+Translation+Rotation+Distortion",
            "params": {
                "n_spots": 6,
                "spot_spacing": 22.0,
                "rotation": 45.0,
                "scale": 0.7,
                "translation": (2.0, 2.0),
                "distortion": {"type": "radial", "k1": 2e-3, "k2": 0.0},
            },
        },
    ]

    for cfg in configs:
        params = dict(
            image_size=image_size,
            n_spots=4,
            spot_spacing=60.0,
            amplitude=1.0,
            sigma=8.0,
            noise_level=0.02,
        )
        params.update(cfg["params"])

        data = make_spot_lattice(**params)

        png_file = os.path.join(OUTPUT_DIR_PNG, f"lattice_{cfg['name']}.png")
        create_2d_plot(
            data,
            title=cfg["title"],
            output_file=png_file,
            center_origin=False,
            show_centroid=False,
        )
        print(f"Saved: {png_file}")

                                    
        tif_file = os.path.join(OUTPUT_DIR_TIF, f"lattice_{cfg['name']}.tif")
        make_spot_lattice(**params, output_path=tif_file)

    print(f"\nPNG images saved to: {OUTPUT_DIR_PNG}")
    print(f"TIFF images saved to: {OUTPUT_DIR_TIF}")


if __name__ == "__main__":
    main()
