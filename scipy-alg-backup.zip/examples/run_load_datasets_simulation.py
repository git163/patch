import numpy as np
import os

import sys
sys.path.insert(0, "img_alg/src")

from img_alg.core.functions import (
    BilateralRect, RisingEdge, FallingEdge,
    Gaussian, SuperGaussian, HyperbolicCosine,
)
from img_alg.datasets import make_spot
from img_alg.visualization.plotting import create_plot_1d, create_2d_plot, create_comparison_plot


_FUNC_MAP = {
    'bilateral_rect': BilateralRect,
    'rising_edge': RisingEdge,
    'falling_edge': FallingEdge,
    'gaussian': Gaussian,
    'super_gaussian': SuperGaussian,
    'hyperbolic_cosine': HyperbolicCosine,
}


def create_function(func_type, **params):
    """创建指定类型的函数实例"""
    if func_type not in _FUNC_MAP:
        raise ValueError(f"不支持的函数类型: {func_type}")
    return _FUNC_MAP[func_type](**params)


             
def create_new_functions():
    """创建新模块的函数实例，返回 (name, func, model_name, params) 列表"""
    entries = [
        ('erf双边', 'bilateral_rect',
         dict(k=100, cx=50, cy=150, R=30,
              sigma1=3, sigma2=4, bg=10, slope=0.1)),
        ('erf上升沿', 'rising_edge',
         dict(k=100, cx=50, cy=40, R=30,
              sigma=4, bg=10, slope=0.1)),
        ('erf下降沿', 'falling_edge',
         dict(k=100, cx=50, cy=40, R=30,
              sigma=4, bg=10, slope=0.1)),
        ('双曲余弦', 'hyperbolic_cosine',
         dict(amplitude=2.0, cx=50, cy=40, width=20.0)),
        ('高斯函数', 'gaussian',
         dict(amplitude=1.5, cx=70, cy=60, sigma=20.0)),
        ('超级高斯', 'super_gaussian',
         dict(amplitude=2.0, cx=70, cy=80, sigma=20.0, n=3)),
    ]

    return [
        (name, create_function(model_name, **params), model_name, params)
        for name, model_name, params in entries
    ]


             
new_functions = create_new_functions()


                                    
def plot_1d_functions():
    import os

    OUTPUT_DIR = "data/image/simulation/1d"              
    os.makedirs(OUTPUT_DIR, exist_ok=True)
                                                
    print("使用新方法生成函数图像...")
    for name, func, _, _ in new_functions:
        try:
            x_range = (0, 100)
            filename = f'test_{name.replace(" ", "_").lower()}_new.png'
            create_plot_1d(func, x_range=x_range, title=f"{name} 函数图像",
                           output_file=f"{OUTPUT_DIR}/{filename}")
            print(f"✓ 新方法已保存: {filename}")
        except Exception as e:
            print(f"✗ 新方法绘制 {name} 失败: {e}")

    output_file = f"{OUTPUT_DIR}/test_erf组合图.png"
    create_comparison_plot(
        [func for _, func, _, _ in new_functions][:3],
        title="erf函数对比图",
        output_file=output_file,
    )


def plot_2d_functions():
    import os

    OUTPUT_DIR = "data/image/simulation/2d"              
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("生成2D函数仿真图像...")
    for name, _, model_name, params in new_functions:
        try:
                      
            image_size = 200
            data_2d = make_spot(
                model=model_name,
                image_size=image_size,
                noise_level=2,
                **params,
            )

                     
            title = f"{name} 2D仿真结果"
            output_file = f"{OUTPUT_DIR}/test_{name}_2d.png"

            create_2d_plot(data_2d, title=title, output_file=output_file)

        except Exception as e:
            print(f"✗ 生成 {name} 2D图像失败: {e}")

    print(f"\n2D函数仿真完成！")
    print(f"输出目录: data/image/simulation/2d")
    print(f"生成的文件:")
    print(f"  - 单个函数2D图像")
    print(f"  - 函数对比图")


plot_1d_functions()
plot_2d_functions()

                                     
print("\n" + "=" * 80)
print("参数说明表")
print("=" * 80)

       


print("\n公式总结:")
print("• 双边erf   = 上升沿 + 下降沿")
print("• 上升沿     = k/2 * erf((x-x0+R)/(sqrt(2)*σ2)) + bg + (x-x0)*slope")
print("• 下降沿     = -k/2 * erf((x-x0-R)/(sqrt(2)*σ1)) + bg + (x-x0)*slope")
print("• 双曲余弦   = A * cosh((x-c)/w)")
print("• 高斯函数   = A * exp(-(x-c)²/(2σ²))")
print("• 超级高斯   = A * exp(-(x-c)^(2n)/(2σ^(2n)))")
print("\n代码特点:")
print("• 采用面向对象设计，易于扩展")
print("• 统一的接口和参数管理")
print("• 模块化结构，便于维护")
print("• 自动生成可视化图表")
print(f"• 输出目录: data/image/simulation/2d (可通过修改OUTPUT_DIR变量更改)")
print("• 所有图片已保存到指定目录")

                                    
print(f"\n📁 配置说明:")
print(f"   当前输出目录: data/image/simulation/2d")
print(f"   要更改输出目录，只需修改变量: OUTPUT_DIR = '新的/路径'")
print(f"   所有函数实例化时都会使用这个统一路径")
