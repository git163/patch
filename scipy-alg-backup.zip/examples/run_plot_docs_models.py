                      
"""
生成模型 1D / 2D 曲线图，用于文档展示
"""

import os
import sys
import numpy as np

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_PROJECT_ROOT, 'img_alg', 'src'))

from img_alg.core.functions import (
    BilateralRect, RisingEdge, FallingEdge,
    Gaussian, SuperGaussian, HyperbolicCosine
)
from img_alg.visualization.plotting import (
    create_plot_1d, create_comparison_plot, create_2d_plot
)

OUTPUT_DIR = os.path.join(_PROJECT_ROOT, 'docs', 'images')
os.makedirs(OUTPUT_DIR, exist_ok=True)


def _param_str(func):
    """根据函数类型格式化参数标注"""
    params = func.params

    def fmt(v):
        if isinstance(v, float):
            return f"{v:.2f}" if abs(v) < 1000 else f"{v:.1f}"
        return str(v)

    if isinstance(func, BilateralRect):
        return (
            f"$k$={fmt(params['k'])}, $x_0$={fmt(params['x0'])}, $R$={fmt(params['R'])}\n"
            f"$\\sigma_1$={fmt(params['sigma1'])}, $\\sigma_2$={fmt(params['sigma2'])}, "
            f"bg={fmt(params['bg'])}, slope={fmt(params['slope'])}"
        )
    elif isinstance(func, (RisingEdge, FallingEdge)):
        return (
            f"$k$={fmt(params['k'])}, $x_0$={fmt(params['x0'])}, $R$={fmt(params['R'])}\n"
            f"$\\sigma$={fmt(params['sigma'])}, "
            f"bg={fmt(params['bg'])}, slope={fmt(params['slope'])}"
        )
    elif isinstance(func, Gaussian):
        return (
            f"$A$={fmt(params['amplitude'])}, $c_x$={fmt(params['cx'])}, "
            f"$\\sigma$={fmt(params['sigma'])}"
        )
    elif isinstance(func, SuperGaussian):
        return (
            f"$A$={fmt(params['amplitude'])}, $c_x$={fmt(params['cx'])}, "
            f"$\\sigma$={fmt(params['sigma'])}, $n$={fmt(params['n'])}"
        )
    elif isinstance(func, HyperbolicCosine):
        return (
            f"$A$={fmt(params['amplitude'])}, $c_x$={fmt(params['cx'])}, "
            f"$w$={fmt(params['width'])}"
        )
    return ""


class _NamedFuncWrapper:
    """轻量包装器，用于在不修改原函数对象的前提下覆盖显示名称"""

    def __init__(self, func, name):
        self._func = func
        self.name = name

    def calculate1d(self, x):
        return self._func.calculate1d(x)

    def calculate2d(self, x, y):
        return self._func.calculate2d(x, y)


def plot_1d_erf():
    """ERF 族 1D 对比图"""
    funcs = [
        BilateralRect(k=100, cx=50, R=20, sigma1=3, sigma2=4, bg=10, slope=0.02),
        RisingEdge(k=100, cx=50, R=20, sigma=4, bg=10, slope=0.02),
        FallingEdge(k=100, cx=50, R=20, sigma=3, bg=10, slope=0.02),
    ]
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c']
    labels = [f"{func.name}\n{_param_str(func)}" for func in funcs]
    wrapped = [_NamedFuncWrapper(func, label) for func, label in zip(funcs, labels)]

    out = os.path.join(OUTPUT_DIR, '1d_erf_models.png')
    create_comparison_plot(
        wrapped,
        x_range=(0, 100),
        title="ERF 族模型 1D 曲线",
        output_file=out,
        colors=colors,
    )
    print(f"Saved: {out}")


def plot_1d_gaussian():
    """Gaussian 族 1D 对比图"""
    funcs = [
        Gaussian(amplitude=1.0, cx=0.0, sigma=1.0),
        SuperGaussian(amplitude=1.0, cx=0.0, sigma=1.0, n=4.0),
        HyperbolicCosine(amplitude=1.0, cx=0.0, width=2.0),
    ]
    colors = ['#9467bd', '#e377c2', '#7f7f7f']
    labels = [f"{func.name}\n{_param_str(func)}" for func in funcs]
    wrapped = [_NamedFuncWrapper(func, label) for func, label in zip(funcs, labels)]

    out = os.path.join(OUTPUT_DIR, '1d_gaussian_models.png')
    create_comparison_plot(
        wrapped,
        x_range=(-5, 5),
        title="Gaussian 族模型 1D 曲线",
        output_file=out,
        colors=colors,
    )
    print(f"Saved: {out}")


def plot_2d_model(func, filename):
    """单个模型 2D 热力图"""
    size = 128
    x = np.linspace(0, size - 1, size)
    y = np.linspace(0, size - 1, size)
    X, Y = np.meshgrid(x, y)
    data = func.calculate2d(X, Y)

    out = os.path.join(OUTPUT_DIR, filename)
    create_2d_plot(
        data,
        title=f"{func.name} 2D 分布\n{_param_str(func)}",
        output_file=out,
        center_origin=False,
        show_centroid=False,
    )
    print(f"Saved: {out}")


def main():
    plot_1d_erf()
    plot_1d_gaussian()

    plot_2d_model(
        BilateralRect(k=5000, cx=64, cy=64, R=30, sigma1=6, sigma2=8, bg=50, slope=0.5),
        '2d_erf_bilateralrect.png'
    )
    plot_2d_model(
        RisingEdge(k=5000, cx=64, cy=64, R=30, sigma=8, bg=50, slope=0.5),
        '2d_erf_risingedge.png'
    )
    plot_2d_model(
        FallingEdge(k=5000, cx=64, cy=64, R=30, sigma=6, bg=50, slope=0.5),
        '2d_erf_fallingedge.png'
    )
    plot_2d_model(
        Gaussian(amplitude=1.0, cx=64.0, cy=50.0, sigma=20.0),
        '2d_gaussian_gaussian.png'
    )
    plot_2d_model(
        SuperGaussian(amplitude=1.0, cx=64.0, cy=50.0, sigma=20.0, n=4.0),
        '2d_gaussian_supergaussian.png'
    )
    plot_2d_model(
        HyperbolicCosine(amplitude=1.0, cx=64.0, cy=50.0, width=15.0),
        '2d_gaussian_hyperboliccosine.png'
    )


if __name__ == '__main__':
    main()
