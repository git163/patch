                      
"""
自动运行 examples 目录下所有示例脚本的入口程序。
"""

import glob
import os
import subprocess
import sys


def collect_scripts(directory: str) -> list[str]:
    """收集指定目录下的所有 Python 脚本，按文件名排序。"""
    pattern = os.path.join(directory, "*.py")
    scripts = sorted(glob.glob(pattern))
    return scripts


def run_script(script_path: str, timeout: int = 120) -> dict:
    """使用 subprocess 运行单个脚本，返回执行结果摘要。"""
    env = os.environ.copy()
                                                  
    env["MPLBACKEND"] = "Agg"

    print(f"\n{'='*60}")
    print(f"Running: {script_path}")
    print("=" * 60)

    result = {"script": script_path, "status": "success", "returncode": 0}
    try:
        proc = subprocess.run(
            [sys.executable, script_path],
            env=env,
            timeout=timeout,
            capture_output=True,
            text=True,
        )
                    
        if proc.stdout:
            print(proc.stdout, end="")
        if proc.stderr:
            print(proc.stderr, end="", file=sys.stderr)

        result["returncode"] = proc.returncode
        if proc.returncode != 0:
            result["status"] = "failed"
    except subprocess.TimeoutExpired as e:
        print(f"[TIMEOUT] {script_path} exceeded {timeout} seconds")
        if e.stdout:
            print(e.stdout, end="")
        if e.stderr:
            print(e.stderr, end="", file=sys.stderr)
        result["status"] = "timeout"
        result["returncode"] = -1
    except Exception as e:
        print(f"[ERROR] {script_path}: {e}")
        result["status"] = "error"
        result["returncode"] = -1

    return result


def main() -> int:
    examples_dir = os.path.dirname(os.path.abspath(__file__))
    scripts = collect_scripts(examples_dir)

                 
    self_name = os.path.basename(__file__)
    scripts = [s for s in scripts if os.path.basename(s) != self_name]

    if not scripts:
        print("No example scripts found.")
        return 0

    print(f"Found {len(scripts)} example script(s) to run:")
    for s in scripts:
        print(f"  - {os.path.basename(s)}")

    results = []
    for script in scripts:
        results.append(run_script(script))

          
    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    success_count = sum(1 for r in results if r["status"] == "success")
    failed_count = len(results) - success_count

    for r in results:
        basename = os.path.basename(r["script"])
        status = r["status"].upper()
        print(f"  [{status}] {basename}")

    print(f"\nTotal: {len(results)} | Success: {success_count} | Failed: {failed_count}")
    return 1 if failed_count > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
