                      
"""
Image Algorithm - 快速演示

展示图像分析系统的主要功能（使用工厂模式统一调用）
"""

import argparse
import os
import sys

                        
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_PROJECT_ROOT, 'img_alg', 'src'))

from img_alg.algorithms import AnalyzerFactory, SpotAnalyzer

        
_DEFAULT_OUTPUT_DIR = os.path.join(_PROJECT_ROOT, 'data', 'results')
_FITTING_PLOT_DIR = os.path.join(_DEFAULT_OUTPUT_DIR, 'fitting')
_CUSTOM_RESULTS_DIR = os.path.join(_PROJECT_ROOT, 'demo', 'custom_results')


def _print_center(center: tuple) -> None:
    """打印光斑中心位置。"""
    print(f"   光斑中心位置: ({center[0]:.3f}, {center[1]:.3f}) 像素")


def _count_successful_fits(edge_results: dict) -> int:
    """统计拟合成功的方向数。"""
    return sum(
        1 for result in edge_results.values()
        if 'error' not in result.get('fit_params', {}) and result['fit_params'].get('r_squared', 0) > 0
    )


def _save_fitting_plots(analyzer, edge_results: dict, output_dir: str) -> None:
    """保存拟合图到指定目录。"""
    os.makedirs(output_dir, exist_ok=True)
    analyzer.plotter.save_fitting_plots = True

    for direction in edge_results.keys():
        fig_path = os.path.join(output_dir, f'fitting_{direction}.png')
        analyzer.plotter.plot_fitting_results(edge_results, direction, fig_path)
        print(f"   方向 {direction}° 拟合图已保存到: {fig_path}")

    all_fig_path = os.path.join(output_dir, 'all_directions_fitting.png')
    analyzer.plotter.plot_fitting_results(edge_results, 'all', all_fig_path)
    print(f"   综合拟合图已保存到: {all_fig_path}")


def _save_results(analyzer, results: dict, output_dir: str, fmt: str = 'csv') -> bool:
    """保存分析结果并打印状态。"""
    success = analyzer.save_results(results, output_dir, format_type=fmt)
    if success:
        print(f"   结果已保存为 {fmt.upper()} 到: {output_dir}")
    else:
        print(f"   结果保存失败")
    return success


def _print_horizontal_fit(edge_results: dict) -> None:
    """打印水平方向（0°）拟合信息。"""
    horizontal = edge_results.get('0', {})
    fit_params = horizontal.get('fit_params', {})
    if fit_params and 'error' not in fit_params:
        r_squared = fit_params.get('r_squared', 0)
        R_value = fit_params.get('R', 0)
        model_type = fit_params.get('model_type', 'unknown')
        print(f"   水平方向拟合: R^2={r_squared:.4f}, R={R_value:.3f}, 模型={model_type}")


def quick_simulation_demo() -> int:
    """仿真模式快速演示"""
    print("=" * 60)
    print("Image Algorithm - 仿真模式演示 (工厂模式)")
    print("=" * 60)

    try:
        print("\n1. 通过工厂创建分析器实例...")
        analyzer = AnalyzerFactory.create("spot")
        print("   成功创建分析器")

        print("\n2. 开始处理仿真数据...")
        error_code, results = analyzer.process({"mode": "simulation"})

        if error_code != 0 or results is None:
            print(f"   处理失败，错误码: {error_code}")
            return error_code

        print("   仿真数据处理成功")
        _print_center(results['center'])

        edge_results = results['edge_analysis']
        successful_fits = _count_successful_fits(edge_results)
        print(f"   边缘模糊分析: {successful_fits}/{len(edge_results)} 方向拟合成功")

        _print_horizontal_fit(edge_results)
        _save_fitting_plots(analyzer, edge_results, _FITTING_PLOT_DIR)
        _save_results(analyzer, results, _DEFAULT_OUTPUT_DIR, fmt='csv')

        return 0

    except Exception as e:
        print(f"   错误: {e}")
        return -1


def quick_configuration_demo() -> int:
    """配置管理快速演示"""
    print("\n" + "=" * 60)
    print("Image Algorithm - 配置管理演示")
    print("=" * 60)

    try:
        print("\n1. 使用自定义配置...")
        analyzer = AnalyzerFactory.create(
            "spot",
            data_source='simulation',
            image_size=128,
            sample_config_size=64,
            center_method='centroid',
            basic_config={'output_dir': os.path.join(_PROJECT_ROOT, 'custom_results')},
        )
        assert isinstance(analyzer, SpotAnalyzer)

        config = analyzer.config_manager.get_basic_config()
        print("   配置加载成功:")
        print(f"     • 数据源: {config['data_source']}")
        print(f"     • 图像尺寸: {config['image_size']}×{config['image_size']}")
        print(f"     • 采样范围: {config['sample_config_size']}")
        print(f"     • 中心方法: {config['center_method']}")

        print("\n2. 使用自定义配置处理数据...")
        error_code, results = analyzer.process({"mode": "simulation"})

        if error_code != 0 or results is None:
            print(f"   处理失败，错误码: {error_code}")
            return error_code

        print("   自定义配置处理成功")
        _print_center(results['center'])
        _save_results(analyzer, results, _CUSTOM_RESULTS_DIR, fmt='csv')

        return 0

    except Exception as e:
        print(f"   错误: {e}")
        return -1


def main() -> int:
    """主函数"""
    parser = argparse.ArgumentParser(
        description="图像分析系统 (Image Algorithm) - 快速演示"
    )
    parser.add_argument(
        '--demo',
        choices=['simulation', 'configuration', 'all'],
        default='simulation',
        help='选择要运行的演示 (默认: simulation)'
    )
    args = parser.parse_args()

    print("图像分析系统 (Image Algorithm)")
    print("专业的光斑特性分析和 ERF 模型拟合工具")
    print("当前可用分析器:", ", ".join(AnalyzerFactory.list_analyzers()))
    print()

    exit_code = 0
    if args.demo in ('simulation', 'all'):
        exit_code = quick_simulation_demo() or exit_code
    if args.demo in ('configuration', 'all'):
        exit_code = quick_configuration_demo() or exit_code

    return exit_code


if __name__ == "__main__":
    sys.exit(main())
