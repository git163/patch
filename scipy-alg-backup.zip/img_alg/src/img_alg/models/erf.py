"""
ERF 模型显式 Estimator 类。
"""

from ._base import SpotEstimator
from ..core.functions.erf import BilateralRect, RisingEdge, FallingEdge


class BilateralRectEstimator(SpotEstimator):
    """双边 erf 拟合模型。"""
    _mathfunc_class = BilateralRect


class RisingEdgeEstimator(SpotEstimator):
    """单边上升沿 erf 拟合模型。"""
    _mathfunc_class = RisingEdge


class FallingEdgeEstimator(SpotEstimator):
    """单边下降沿 erf 拟合模型。"""
    _mathfunc_class = FallingEdge
