"""
基于 sklearn 风格的一维光斑模型估计器基类。
"""

import numpy as np
from scipy.optimize import curve_fit


def _make_curve_fit_func(static_func, param_order):
    """为 scipy.optimize.curve_fit 包装 **kwargs 接口的静态方法。"""
    def wrapper(x, *args):
        kwargs = dict(zip(param_order, args))
        return static_func(x, **kwargs)
    return wrapper


def _curve_fit_with_fallback(f, xdata, ydata, p0, bounds, maxfev=5000):
    """执行带约束的 curve_fit，失败时回退到无约束拟合。"""
    try:
        popt, pcov = curve_fit(f, xdata, ydata, p0=p0, bounds=bounds, maxfev=maxfev)
        success = True
    except Exception as e:
                  
        popt, pcov = curve_fit(f, xdata, ydata, p0=p0)
        success = False
    return popt, pcov, success


def _pcov_to_std(pcov):
    """从 covariance matrix 计算参数标准差。"""
    if pcov is None:
        return None
    return np.sqrt(np.diag(pcov))


class SpotEstimator:
    """
    基于 sklearn 风格的一维光斑模型估计器。

    子类必须将 `_mathfunc_class` 设置为 `FittingFunction` 的子类。
    """

    _mathfunc_class = None

    def __init__(self, *, auto_init=True, maxfev=5000):
        self.auto_init = auto_init
        self.maxfev = maxfev

    def fit(self, X, y):
        """
        拟合一维模型。

        Parameters
        ----------
        X : array-like of shape (n_samples,) or (n_samples, 1)
            输入样本
        y : array-like of shape (n_samples,)
            目标值
        """
        X = np.asarray(X).ravel()
        y = np.asarray(y).ravel()
        math_func = self._mathfunc_class()

              
        if self.auto_init:
            init_dict = math_func.estimate_initial_parameters(X, y)
            p0 = [init_dict[p] for p in math_func._params_order]
        else:
            p0 = [math_func._params[p] for p in math_func._params_order]

              
        f = _make_curve_fit_func(
            math_func.__class__.calculate1d_static, math_func._params_order
        )
        popt, pcov, success = _curve_fit_with_fallback(
            f, X, y,
            p0=p0,
            bounds=(math_func._bounds_lower, math_func._bounds_upper),
            maxfev=self.maxfev,
        )

                              
        self.popt_ = popt
        self.pcov_ = pcov
        self.success_ = success
        self.params_order_ = list(math_func._params_order)
        self.params_ = dict(zip(self.params_order_, popt.tolist()))
        self.center_ = self.params_.get("cx", self.params_.get("x0", None))
        for name in self.params_order_:
            setattr(self, f"{name}_", float(self.params_[name]))

                
        self.X_fit_ = X
        self.y_fit_ = y
        kwargs0 = dict(zip(self.params_order_, list(p0)))
        kwargs_opt = dict(zip(self.params_order_, list(popt)))
        self.y_init_ = math_func.__class__.calculate1d_static(X, **kwargs0)
        self.y_pred_ = math_func.__class__.calculate1d_static(X, **kwargs_opt)
        self.residuals_ = y - self.y_pred_

              
        ss_res = float(np.sum(self.residuals_ ** 2))
        ss_tot = float(np.sum((y - np.mean(y)) ** 2))
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        self.diagnostics_ = {
            "r_squared": r2,
            "rmse": float(np.sqrt(np.mean(self.residuals_ ** 2))),
            "mae": float(np.mean(np.abs(self.residuals_))),
            "rss": ss_res,
            "params_std": _pcov_to_std(pcov).tolist() if pcov is not None else None,
        }
        return self

    def predict(self, X):
        """使用拟合参数预测1D曲线值。"""
        if not hasattr(self, "popt_"):
            raise ValueError("Estimator has not been fitted yet.")
        X = np.asarray(X).ravel()
        kwargs = dict(zip(self.params_order_, self.popt_.tolist()))
        return self._mathfunc_class.calculate1d_static(X, **kwargs)

    def score(self, X, y):
        """返回 R² 作为评分。"""
        if not hasattr(self, "diagnostics_"):
            raise ValueError("Estimator has not been fitted yet.")
        return self.diagnostics_["r_squared"]

    def get_params(self, deep=True):
        return {"auto_init": self.auto_init, "maxfev": self.maxfev}

    def set_params(self, **params):
        for k, v in params.items():
            setattr(self, k, v)
        return self
