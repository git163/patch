"""
高斯类模型显式 Estimator 类。
"""

from ._base import SpotEstimator
from ..core.functions.gaussian import Gaussian, SuperGaussian, HyperbolicCosine


class GaussianEstimator(SpotEstimator):
    """高斯拟合模型。"""
    _mathfunc_class = Gaussian


class SuperGaussianEstimator(SpotEstimator):
    """超级高斯拟合模型。"""
    _mathfunc_class = SuperGaussian


class HyperbolicCosineEstimator(SpotEstimator):
    """双曲余弦拟合模型。"""
    _mathfunc_class = HyperbolicCosine
