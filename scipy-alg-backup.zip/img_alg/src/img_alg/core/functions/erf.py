"""
基于erf函数的仿真实现
"""

import numpy as np
from scipy.special import erf
from .base import FittingFunction


class ERFFunction(FittingFunction):
    """
    ERF函数基类

    提供ERF相关函数的公共功能和参数估计逻辑
    """

    @staticmethod
    def _calculate_basic_statistics(x_data: np.ndarray, y_data: np.ndarray) -> tuple:
        """
        计算基本的统计数据（供所有ERF子类使用）

        Args:
            x_data: X坐标数据
            y_data: Y值数据

        Returns:
            tuple: (peak_val, bg_val, weighted_centroid, fwhm_width, slope)
        """
                   
        stats = FittingFunction._estimate_peak_centroid_width(x_data, y_data)
        peak_val = stats["peak"]
        bg_val = stats["bg"]
        weighted_centroid = stats["centroid"]
        fwhm_width = stats["width"]

              
        if len(x_data) >= 2:
            result = np.polyfit(x_data, y_data, 1)
            slope = result[0] if len(result) > 0 else 0.0
        else:
            slope = 0.0

        return peak_val, bg_val, weighted_centroid, fwhm_width, slope

    def _prepare_2d(self, x: np.ndarray, y: np.ndarray, **params) -> np.ndarray:
        """应用参数并计算径向距离 r"""
        def _calc():
            cx, cy = self.get_center_x_y()
            return np.sqrt((x - cx)**2 + (y - cy)**2)
        return self._with_temp_params(params, _calc)


class BilateralRect(ERFFunction):
    """
    双边erf函数 (基于erf)

    公式：I(x) = k/2 * [erf((x - x0 + R)/(sqrt(2)*σ1)) - erf((x - x0 - R)/(sqrt(2)*σ2))] + bg + slope*(x - x0)

    其中：
    - k: 矩形总幅度
    - x0: 中心位置
    - R: 半宽
    - σ1: 左侧过渡宽度
    - σ2: 右侧过渡宽度
    - bg: 背景值
    - slope: 斜率
    """

    _param_order = ['k', 'x0', 'R', 'sigma1', 'sigma2', 'bg', 'slope']
    _param_defaults = {
        'k': 100.0, 'x0': 50.0, 'R': 20.0,
        'sigma1': 3.0, 'sigma2': 4.0, 'bg': 10.0, 'slope': 0.02
    }

    def __init__(self, k: float = 100.0, cx: float = 50.0, cy: float = 0.0, R: float = 20.0,
                 sigma1: float = 3.0, sigma2: float = 4.0, bg: float = 10.0,
                 slope: float = 0.02):
        super().__init__("BilateralRect")
        self.k = k
        self.x0 = cx
        self.cx = cx
        self.cy = cy
        self.R = R
        self.sigma1 = sigma1
        self.sigma2 = sigma2
        self.bg = bg
        self.slope = slope

        self._params_order = self._param_order

              
        self._bounds_lower = [-np.inf, -np.inf, 0, 0, 0, -np.inf, -np.inf]
        self._bounds_upper = [np.inf, np.inf, np.inf, np.inf, np.inf, np.inf, np.inf]

    @staticmethod
    def _calculate1d_impl(x: np.ndarray, k: float, x0: float, R: float,
                          sigma1: float, sigma2: float, bg: float, slope: float) -> np.ndarray:
        sqrt2 = np.sqrt(2)
        term1 = erf((x - x0 + R) / (sigma1 * sqrt2))
        term2 = erf((x - x0 - R) / (sigma2 * sqrt2))
        result = k/2 * (term1 - term2) + bg + (x - x0) * slope
        return result

    @staticmethod
    def calculate1d_static(x: np.ndarray, **kwargs) -> np.ndarray:
        """静态方法计算双边erf函数"""
        defaults = BilateralRect._param_defaults
        return BilateralRect._calculate1d_impl(
            x,
            k=kwargs.get('k', defaults['k']),
            x0=kwargs.get('x0', defaults['x0']),
            R=kwargs.get('R', defaults['R']),
            sigma1=kwargs.get('sigma1', defaults['sigma1']),
            sigma2=kwargs.get('sigma2', defaults['sigma2']),
            bg=kwargs.get('bg', defaults['bg']),
            slope=kwargs.get('slope', defaults['slope'])
        )

    def calculate1d(self, x: np.ndarray, **kwargs) -> np.ndarray:
        """计算双边erf函数"""
        return self._calculate1d_impl(
            x,
            k=kwargs.get('k', self.k),
            x0=kwargs.get('x0', self.x0),
            R=kwargs.get('R', self.R),
            sigma1=kwargs.get('sigma1', self.sigma1),
            sigma2=kwargs.get('sigma2', self.sigma2),
            bg=kwargs.get('bg', self.bg),
            slope=kwargs.get('slope', self.slope)
        )

    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计BilateralRect的初始参数
        """
        peak_val, bg_val, weighted_centroid, fwhm_width, slope = ERFFunction._calculate_basic_statistics(x_data, y_data)

        return {
            'k': max(1.0, peak_val - bg_val),
            'x0': weighted_centroid,
            'R': fwhm_width / 2,
            'sigma1': fwhm_width / 3,
            'sigma2': fwhm_width / 3,
            'bg': bg_val,
            'slope': slope
        }

    def calculate2d(self, x: np.ndarray, y: np.ndarray, **params) -> np.ndarray:
        """
        二维径向对称双边erf函数
        I(r) = k/2 * [erf((r + R)/(sqrt(2)*σ1)) - erf((r - R)/(sqrt(2)*σ2))] + bg + slope * r
        其中 r = sqrt((x-cx)^2 + (y-cy)^2)
        """
        r = self._prepare_2d(x, y, **params)
        sqrt2 = np.sqrt(2)
        return self.k/2 * (erf((r + self.R) / (self.sigma1 * sqrt2)) - erf((r - self.R) / (self.sigma2 * sqrt2))) + self.bg + self.slope * r


class RisingEdge(ERFFunction):
    """
    单边上升沿函数

    公式：I(x) = k/2 * erf((x - x0 + R)/(sqrt(2)*σ)) + bg + slope*(x - x0)

    这是双边erf函数的一半，表示从中心向右的上升部分
    """

    _param_order = ['k', 'x0', 'R', 'sigma', 'bg', 'slope']
    _param_defaults = {
        'k': 100.0, 'x0': 50.0, 'R': 20.0,
        'sigma': 4.0, 'bg': 10.0, 'slope': 0.02
    }

    def __init__(self, k: float = 100.0, cx: float = 50.0, cy: float = 0.0, R: float = 20.0,
                 sigma: float = 4.0, bg: float = 10.0, slope: float = 0.02):
        super().__init__("RisingEdge")
        self.k = k
        self.x0 = cx
        self.cx = cx
        self.cy = cy
        self.R = R
        self.sigma = sigma
        self.bg = bg
        self.slope = slope

        self._params_order = self._param_order

              
        self._bounds_lower = [0, -np.inf, 0, 0, -np.inf, -np.inf]
        self._bounds_upper = [np.inf, np.inf, np.inf, np.inf, np.inf, np.inf]

    @staticmethod
    def _calculate1d_impl(x: np.ndarray, k: float, x0: float, R: float,
                          sigma: float, bg: float, slope: float) -> np.ndarray:
        result = k/2 * erf((x - x0 + R) / (sigma * np.sqrt(2))) + bg + (x - x0) * slope
        return result

    @staticmethod
    def calculate1d_static(x: np.ndarray, **kwargs) -> np.ndarray:
        """静态方法计算上升沿函数"""
        defaults = RisingEdge._param_defaults
        return RisingEdge._calculate1d_impl(
            x,
            k=kwargs.get('k', defaults['k']),
            x0=kwargs.get('x0', defaults['x0']),
            R=kwargs.get('R', defaults['R']),
            sigma=kwargs.get('sigma', defaults['sigma']),
            bg=kwargs.get('bg', defaults['bg']),
            slope=kwargs.get('slope', defaults['slope'])
        )

    def calculate1d(self, x: np.ndarray, **kwargs) -> np.ndarray:
        """计算上升沿函数"""
        return self._calculate1d_impl(
            x,
            k=kwargs.get('k', self.k),
            x0=kwargs.get('x0', self.x0),
            R=kwargs.get('R', self.R),
            sigma=kwargs.get('sigma', self.sigma),
            bg=kwargs.get('bg', self.bg),
            slope=kwargs.get('slope', self.slope)
        )

    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计RisingEdge的初始参数
        """
        bilateral_params = BilateralRect().estimate_initial_parameters(x_data, y_data)

        return {
            'k': bilateral_params['k'],
            'x0': bilateral_params['x0'],
            'R': bilateral_params['R'],
            'sigma': bilateral_params['sigma2'],
            'bg': bilateral_params['bg'],
            'slope': bilateral_params['slope']
        }

    def calculate2d(self, x: np.ndarray, y: np.ndarray, **params) -> np.ndarray:
        """
        二维径向对称计算上升沿函数
        I(r) = k/2 * erf((r - R)/(sqrt(2)*sigma)) + bg + slope * r
        其中 r = sqrt((x-cx)^2 + (y-cy)^2)
        """
        r = self._prepare_2d(x, y, **params)
        return self.k/2 * erf((r - self.R) / (self.sigma * np.sqrt(2))) + self.bg + self.slope * r


class FallingEdge(ERFFunction):
    """
    单边下降沿函数

    公式：I(x) = -k/2 * erf((x - x0 - R)/(sqrt(2)*σ)) + bg + slope*(x - x0)

    这是双边erf函数的一半，表示从中心向左的下降部分
    """

    _param_order = ['k', 'x0', 'R', 'sigma', 'bg', 'slope']
    _param_defaults = {
        'k': 100.0, 'x0': 50.0, 'R': 20.0,
        'sigma': 3.0, 'bg': 10.0, 'slope': 0.02
    }

    def __init__(self, k: float = 100.0, cx: float = 50.0, cy: float = 0.0, R: float = 20.0,
                 sigma: float = 3.0, bg: float = 10.0, slope: float = 0.02):
        super().__init__("FallingEdge")
        self.k = k
        self.x0 = cx
        self.cx = cx
        self.cy = cy
        self.R = R
        self.sigma = sigma
        self.bg = bg
        self.slope = slope

        self._params_order = self._param_order

              
        self._bounds_lower = [0, -np.inf, 0, 0, -np.inf, -np.inf]
        self._bounds_upper = [np.inf, np.inf, np.inf, np.inf, np.inf, np.inf]

    @staticmethod
    def _calculate1d_impl(x: np.ndarray, k: float, x0: float, R: float,
                          sigma: float, bg: float, slope: float) -> np.ndarray:
        result = -k/2 * erf((x - x0 - R) / (sigma * np.sqrt(2))) + bg + (x - x0) * slope
        return result

    @staticmethod
    def calculate1d_static(x: np.ndarray, **kwargs) -> np.ndarray:
        """静态方法计算下降沿函数"""
        defaults = FallingEdge._param_defaults
        return FallingEdge._calculate1d_impl(
            x,
            k=kwargs.get('k', defaults['k']),
            x0=kwargs.get('x0', defaults['x0']),
            R=kwargs.get('R', defaults['R']),
            sigma=kwargs.get('sigma', defaults['sigma']),
            bg=kwargs.get('bg', defaults['bg']),
            slope=kwargs.get('slope', defaults['slope'])
        )

    def calculate1d(self, x: np.ndarray, **kwargs) -> np.ndarray:
        """计算下降沿函数"""
        return self._calculate1d_impl(
            x,
            k=kwargs.get('k', self.k),
            x0=kwargs.get('x0', self.x0),
            R=kwargs.get('R', self.R),
            sigma=kwargs.get('sigma', self.sigma),
            bg=kwargs.get('bg', self.bg),
            slope=kwargs.get('slope', self.slope)
        )

    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计FallingEdge的初始参数
        """
        bilateral_params = BilateralRect().estimate_initial_parameters(x_data, y_data)

        return {
            'k': bilateral_params['k'],
            'x0': bilateral_params['x0'],
            'R': bilateral_params['R'],
            'sigma': bilateral_params['sigma1'],
            'bg': bilateral_params['bg'],
            'slope': bilateral_params['slope']
        }

    def calculate2d(self, x: np.ndarray, y: np.ndarray, **params) -> np.ndarray:
        """
        二维径向对称计算下降沿函数
        I(r) = -k/2 * erf((r - R)/(sqrt(2)*sigma)) + bg + slope * r
        其中 r = sqrt((x-cx)^2 + (y-cy)^2)
        """
        r = self._prepare_2d(x, y, **params)
        return -self.k/2 * erf((r - self.R) / (self.sigma * np.sqrt(2))) + self.bg + self.slope * r
