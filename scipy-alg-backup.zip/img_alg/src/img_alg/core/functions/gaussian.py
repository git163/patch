"""
高斯函数仿真实现
"""

import numpy as np
from typing import Dict, Any
from .base import FittingFunction


class Gaussian(FittingFunction):
    """
    高斯函数

    公式：I(x) = A * exp(-(x - c)²/(2σ²))

    参数：
    - A: 峰值
    - c: 中心位置
    - σ: 标准差
    """

    _param_order = ['amplitude', 'cx', 'sigma']
    _param_defaults = {'amplitude': 1.0, 'cx': 0.0, 'sigma': 1.0}

    def __init__(self, amplitude: float = 1.0, cx: float = 0.0, cy: float = 0.0, sigma: float = 1.0):
        super().__init__("Gaussian")
        self.amplitude = amplitude
        self.cx = cx
        self.cy = cy
        self.sigma = sigma

        self._params_order = self._param_order

              
        self._bounds_lower = [0, -np.inf, 0]
        self._bounds_upper = [np.inf, np.inf, np.inf]

    @staticmethod
    def _calculate1d_impl(x: np.ndarray, amplitude: float, cx: float, sigma: float) -> np.ndarray:
        exponent = -(x - cx)**2 / (2 * sigma**2)
        result = amplitude * np.exp(exponent)
        return result

    @staticmethod
    def calculate1d_static(x: np.ndarray, **kwargs) -> np.ndarray:
        """静态方法计算高斯函数"""
        defaults = Gaussian._param_defaults
        return Gaussian._calculate1d_impl(
            x,
            amplitude=kwargs.get('amplitude', defaults['amplitude']),
            cx=kwargs.get('cx', defaults['cx']),
            sigma=kwargs.get('sigma', defaults['sigma'])
        )

    def calculate1d(self, x: np.ndarray, **kwargs) -> np.ndarray:
        """计算高斯函数"""
        return self._calculate1d_impl(
            x,
            amplitude=kwargs.get('amplitude', self.amplitude),
            cx=kwargs.get('cx', self.cx),
            sigma=kwargs.get('sigma', self.sigma)
        )

    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计Gaussian的初始参数
        """
        stats = self._estimate_peak_centroid_width(x_data, y_data)
        peak_val = stats['peak']
        bg_val = stats['bg']

        weighted_centroid = stats['centroid']
        fwhm_width = stats['width']
        sigma = fwhm_width / (2 * np.sqrt(2 * np.log(2)))

        return {
            'amplitude': max(1.0, peak_val - bg_val),
            'cx': weighted_centroid,
            'cy': 0.0,
            'sigma': sigma
        }


class SuperGaussian(FittingFunction):
    """
    超级高斯函数 (n次幂高斯)

    公式：I(x) = A * exp(-(x - c)^(2n)/(2σ^(2n)))

    参数：
    - A: 峰值
    - c: 中心位置
    - σ: 尺度参数
    - n: 幂次（n越大，函数越尖锐）
    """

    _param_order = ['amplitude', 'cx', 'sigma', 'n']
    _param_defaults = {'amplitude': 1.0, 'cx': 0.0, 'sigma': 1.0, 'n': 2.0}

    def __init__(self, amplitude: float = 1.0, cx: float = 0.0, cy: float = 0.0, sigma: float = 1.0, n: float = 2.0):
        super().__init__("SuperGaussian")
        self.amplitude = amplitude
        self.cx = cx
        self.cy = cy
        self.sigma = sigma
        self.n = n

        self._params_order = self._param_order

              
        self._bounds_lower = [0, -np.inf, 0, 0.1]
        self._bounds_upper = [np.inf, np.inf, np.inf, np.inf]

    @staticmethod
    def _calculate1d_impl(x: np.ndarray, amplitude: float, cx: float, sigma: float, n: float) -> np.ndarray:
        exponent_numerator = -(x - cx)**(2*n)
        exponent_denominator = 2 * sigma**(2*n)
        exponent = exponent_numerator / exponent_denominator
        result = amplitude * np.exp(exponent)
        return result

    @staticmethod
    def calculate1d_static(x: np.ndarray, **kwargs) -> np.ndarray:
        """静态方法计算超级高斯函数"""
        defaults = SuperGaussian._param_defaults
        return SuperGaussian._calculate1d_impl(
            x,
            amplitude=kwargs.get('amplitude', defaults['amplitude']),
            cx=kwargs.get('cx', defaults['cx']),
            sigma=kwargs.get('sigma', defaults['sigma']),
            n=kwargs.get('n', defaults['n'])
        )

    def calculate1d(self, x: np.ndarray, **kwargs) -> np.ndarray:
        """计算超级高斯函数"""
        return self._calculate1d_impl(
            x,
            amplitude=kwargs.get('amplitude', self.amplitude),
            cx=kwargs.get('cx', self.cx),
            sigma=kwargs.get('sigma', self.sigma),
            n=kwargs.get('n', self.n)
        )

    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计SuperGaussian的初始参数
        """
        gaussian_params = Gaussian().estimate_initial_parameters(x_data, y_data)

        return {
            'amplitude': gaussian_params['amplitude'],
            'cx': gaussian_params['cx'],
            'cy': gaussian_params['cy'],
            'sigma': gaussian_params['sigma'],
            'n': 2.0
        }


class HyperbolicCosine(FittingFunction):
    """
    双曲余弦函数

    公式：I(x) = A * cosh((x - c)/w)

    参数：
    - A: 振幅
    - c: 中心位置
    - w: 宽度参数
    """

    _param_order = ['amplitude', 'cx', 'width']
    _param_defaults = {'amplitude': 1.0, 'cx': 0.0, 'width': 2.0}

    def __init__(self, amplitude: float = 1.0, cx: float = 0.0, cy: float = 0.0, width: float = 2.0):
        super().__init__("HyperbolicCosine")
        self.amplitude = amplitude
        self.cx = cx
        self.cy = cy
        self.width = width

        self._params_order = self._param_order

              
        self._bounds_lower = [0, -np.inf, 0]
        self._bounds_upper = [np.inf, np.inf, np.inf]

    @staticmethod
    def _calculate1d_impl(x: np.ndarray, amplitude: float, cx: float, width: float) -> np.ndarray:
        argument = (x - cx) / width
        result = amplitude * np.cosh(argument)
        return result

    @staticmethod
    def calculate1d_static(x: np.ndarray, **kwargs) -> np.ndarray:
        """静态方法计算双曲余弦函数"""
        defaults = HyperbolicCosine._param_defaults
        return HyperbolicCosine._calculate1d_impl(
            x,
            amplitude=kwargs.get('amplitude', defaults['amplitude']),
            cx=kwargs.get('cx', defaults['cx']),
            width=kwargs.get('width', defaults['width'])
        )

    def calculate1d(self, x: np.ndarray, **kwargs) -> np.ndarray:
        """计算双曲余弦函数"""
        return self._calculate1d_impl(
            x,
            amplitude=kwargs.get('amplitude', self.amplitude),
            cx=kwargs.get('cx', self.cx),
            width=kwargs.get('width', self.width)
        )

    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计HyperbolicCosine的初始参数
        """
        stats = self._estimate_peak_centroid_width(x_data, y_data)
        peak_val = stats['peak']
        bg_val = stats['bg']

        return {
            'amplitude': max(1.0, peak_val - bg_val),
            'cx': stats['centroid'],
            'cy': 0.0,
            'width': stats['width']
        }
