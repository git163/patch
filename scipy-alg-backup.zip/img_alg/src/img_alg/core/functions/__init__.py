"""数学函数模块"""

from .base import ParametrizedFunctionBase, FittingFunction
from .erf import ERFFunction, BilateralRect, RisingEdge, FallingEdge
from .gaussian import Gaussian, SuperGaussian, HyperbolicCosine
from .distortion import (
    DistortionFunction,
    RadialDistortion,
    TangentialDistortion,
    SineWaveDistortion,
    PerspectiveDistortion,
)

__all__ = [
    'ParametrizedFunctionBase',
    'FittingFunction',
    'ERFFunction',
    'BilateralRect',
    'RisingEdge',
    'FallingEdge',
    'Gaussian',
    'SuperGaussian',
    'HyperbolicCosine',
    'DistortionFunction',
    'RadialDistortion',
    'TangentialDistortion',
    'SineWaveDistortion',
    'PerspectiveDistortion',
]
