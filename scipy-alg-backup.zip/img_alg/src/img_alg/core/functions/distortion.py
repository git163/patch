"""
坐标变换畸变函数。

提供径向、切向、正弦波和透视畸变，均为独立的 DistortionFunction 子类。
"""

from abc import abstractmethod
import numpy as np
from .base import ParametrizedFunctionBase


class DistortionFunction(ParametrizedFunctionBase):
    """
    二维坐标畸变函数基类。

    畸变函数将 (x, y) 坐标映射为 (x', y')。
    """

    def __init__(self, name: str):
        super().__init__(name)

    @abstractmethod
    def distort(self, x: np.ndarray, y: np.ndarray, **params) -> tuple:
        """
        对坐标应用畸变。

        Args:
            x: X 坐标
            y: Y 坐标
            **params: 可选的参数覆盖

        Returns:
            tuple(np.ndarray, np.ndarray): 畸变后的 (x, y)
        """
        raise NotImplementedError("Subclasses must implement distort()")

    def _distort_impl(self, x: np.ndarray, y: np.ndarray, **resolved) -> tuple:
        """
        子类应重写此纯方法，使用完全解析后的参数执行实际的坐标畸变。
        """
        raise NotImplementedError("Subclasses must implement _distort_impl()")


class RadialDistortion(DistortionFunction):
    """
    径向镜头畸变。

    公式：
        X = x - cx, Y = y - cy
        r2 = X^2 + Y^2
        factor = 1 + k1 * r2 + k2 * r2^2
        x' = cx + X * factor
        y' = cy + Y * factor
    """

    def __init__(self, k1: float = 0.0, k2: float = 0.0, cx: float = 0.0, cy: float = 0.0):
        super().__init__("radial_distortion")
        self.k1 = k1
        self.k2 = k2
        self.cx = cx
        self.cy = cy
        self._params_order = ["k1", "k2", "cx", "cy"]

    def _distort_impl(self, x: np.ndarray, y: np.ndarray, **resolved) -> tuple:
        k1 = resolved["k1"]
        k2 = resolved["k2"]
        cx = resolved["cx"]
        cy = resolved["cy"]
        X = x - cx
        Y = y - cy
        r2 = X ** 2 + Y ** 2
        factor = 1.0 + k1 * r2 + k2 * r2 ** 2
        return cx + X * factor, cy + Y * factor

    def distort(self, x: np.ndarray, y: np.ndarray, **params) -> tuple:
        resolved = self._resolve_params(params)
        return self._with_temp_params(params, self._distort_impl, x, y, **resolved)


class TangentialDistortion(DistortionFunction):
    """
    切向（偏心）畸变。

    公式：
        X = x - cx, Y = y - cy
        r2 = X^2 + Y^2
        x' = x + 2 * p1 * X * Y + p2 * (r2 + 2 * X^2)
        y' = y + p1 * (r2 + 2 * Y^2) + 2 * p2 * X * Y
    """

    def __init__(self, p1: float = 0.0, p2: float = 0.0, cx: float = 0.0, cy: float = 0.0):
        super().__init__("tangential_distortion")
        self.p1 = p1
        self.p2 = p2
        self.cx = cx
        self.cy = cy
        self._params_order = ["p1", "p2", "cx", "cy"]

    def _distort_impl(self, x: np.ndarray, y: np.ndarray, **resolved) -> tuple:
        p1 = resolved["p1"]
        p2 = resolved["p2"]
        cx = resolved["cx"]
        cy = resolved["cy"]
        X = x - cx
        Y = y - cy
        r2 = X ** 2 + Y ** 2
        x_dist = x + 2 * p1 * X * Y + p2 * (r2 + 2 * X ** 2)
        y_dist = y + p1 * (r2 + 2 * Y ** 2) + 2 * p2 * X * Y
        return x_dist, y_dist

    def distort(self, x: np.ndarray, y: np.ndarray, **params) -> tuple:
        resolved = self._resolve_params(params)
        return self._with_temp_params(params, self._distort_impl, x, y, **resolved)


class SineWaveDistortion(DistortionFunction):
    """
    正弦波坐标扭曲。

    公式：
        x' = x + amplitude * sin(frequency * (y - cy) * pi)
        y' = y + amplitude * sin(frequency * (x - cx) * pi)
    """

    def __init__(self, amplitude: float = 0.0, frequency: float = 2.0, cx: float = 0.0, cy: float = 0.0):
        super().__init__("sine_wave_distortion")
        self.amplitude = amplitude
        self.frequency = frequency
        self.cx = cx
        self.cy = cy
        self._params_order = ["amplitude", "frequency", "cx", "cy"]

    def _distort_impl(self, x: np.ndarray, y: np.ndarray, **resolved) -> tuple:
        amplitude = resolved["amplitude"]
        frequency = resolved["frequency"]
        cx = resolved["cx"]
        cy = resolved["cy"]
        x_dist = x + amplitude * np.sin(frequency * (y - cy) * np.pi)
        y_dist = y + amplitude * np.sin(frequency * (x - cx) * np.pi)
        return x_dist, y_dist

    def distort(self, x: np.ndarray, y: np.ndarray, **params) -> tuple:
        resolved = self._resolve_params(params)
        return self._with_temp_params(params, self._distort_impl, x, y, **resolved)


class PerspectiveDistortion(DistortionFunction):
    """
    透视（剪切）畸变。

    公式：
        x' = x + shear_x * (y - cy)
        y' = y + shear_y * (x - cx)
    """

    def __init__(self, shear_x: float = 0.0, shear_y: float = 0.0, cx: float = 0.0, cy: float = 0.0):
        super().__init__("perspective_distortion")
        self.shear_x = shear_x
        self.shear_y = shear_y
        self.cx = cx
        self.cy = cy
        self._params_order = ["shear_x", "shear_y", "cx", "cy"]

    def _distort_impl(self, x: np.ndarray, y: np.ndarray, **resolved) -> tuple:
        shear_x = resolved["shear_x"]
        shear_y = resolved["shear_y"]
        cx = resolved["cx"]
        cy = resolved["cy"]
        x_dist = x + shear_x * (y - cy)
        y_dist = y + shear_y * (x - cx)
        return x_dist, y_dist

    def distort(self, x: np.ndarray, y: np.ndarray, **params) -> tuple:
        resolved = self._resolve_params(params)
        return self._with_temp_params(params, self._distort_impl, x, y, **resolved)
