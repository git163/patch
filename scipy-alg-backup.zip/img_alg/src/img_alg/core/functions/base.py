"""
仿真函数基类定义
"""

import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, Any


class ParametrizedFunctionBase(ABC):
    """
    参数化函数公共基类

    统一参数同步、字典管理和 override 逻辑，供 FittingFunction 和 DistortionFunction 复用。
    """

    _params_order = []

    def __init__(self, name: str):
        self.name = name
        self._params = {}
        self._params_order = list(getattr(self.__class__, '_params_order', []))
        self._bounds_lower = []
        self._bounds_upper = []

    def __setattr__(self, key, value):
        super().__setattr__(key, value)
        if not hasattr(self, '_params'):
            return
        if key == '_params_order':
                                                       
            for name in value:
                if hasattr(self, name):
                    self._params[name] = getattr(self, name)
                                 
            if hasattr(self, 'cx'):
                self._params['cx'] = self.cx
            if hasattr(self, 'cy'):
                self._params['cy'] = self.cy
        elif key != '_params':
            order = getattr(self, '_params_order', [])
            if key in order or key in ('cx', 'cy'):
                self._params[key] = value

    def get_param_index(self, param_name: str) -> int:
        """
        根据参数名返回对应的索引值
        """
        if param_name == 'x':
            return -1
        try:
            if param_name in ['x0', 'cx']:
                if 'cx' in self._params_order:
                    return self._params_order.index('cx')
                elif 'x0' in self._params_order:
                    return self._params_order.index('x0')
            else:
                return self._params_order.index(param_name)
        except ValueError:
            raise ValueError(f"Parameter '{param_name}' is not in params_order")

    @property
    def params_order(self):
        """
        获取参数顺序列表
        """
        return self._params_order

    @property
    def params(self):
        """
        获取参数字典
        """
        return self._params.copy()

    def get_params_dict(self) -> Dict[str, Any]:
        """
        获取参数字典（供基类访问）

        Returns:
            包含所有参数的字典
        """
        return self._params.copy()

    def get_center_x_y(self):
        """
        获取中心位置参数（如果存在）

        Returns:
            中心位置值，或None如果没有定义
        """
        cx = self._params.get("cx", None)
        cy = self._params.get("cy", None)
        return cx, cy

    def _resolve_params(self, overrides: dict) -> dict:
        """合并 overrides 得到一份纯参数字典，不修改 self。"""
        merged = self._params.copy()
        merged.update({k: v for k, v in overrides.items() if k in self._params_order})
        return merged

    def _with_temp_params(self, overrides: dict, fn, *args, **kwargs):
        """
        在临时应用 overrides 的状态下执行 fn(*args, **kwargs)，
        执行完毕后恢复原来的参数，避免副作用。
        """
        if not overrides:
            return fn(*args, **kwargs)
        old_values = {k: getattr(self, k) for k in overrides if hasattr(self, k)}
        try:
            for k, v in overrides.items():
                if hasattr(self, k):
                    setattr(self, k, v)
            return fn(*args, **kwargs)
        finally:
            for k, v in old_values.items():
                setattr(self, k, v)


class FittingFunction(ParametrizedFunctionBase):
    """
    拟合函数基类

    提供统一的接口用于各种数学函数的仿真数据生成和拟合
    """

    def __init__(self, name: str):
        super().__init__(name)

    def _get_calculate1d_static_param_order(self) -> list:
        """
        获取calculate1d_static方法的参数顺序（排除第一个参数x）

        Returns:
            list: 参数名列表，不包含第一个参数'x'
        """
        return list(getattr(self.__class__, '_param_order', []))

    @abstractmethod
    def calculate1d(self, x: np.ndarray, **params) -> np.ndarray:
        """
        计算一维函数值

        Args:
            x: 输入数组
            **params: 函数参数

        Returns:
            计算结果数组
        """
        raise NotImplementedError("Subclasses must implement calculate1d()")

    @abstractmethod
    def estimate_initial_parameters(self, x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估计初始参数

        Args:
            x_data: X坐标数据
            y_data: Y值数据

        Returns:
            dict: 初始参数字典
        """
        raise NotImplementedError("Subclasses must implement estimate_initial_parameters()")

    @staticmethod
    def _estimate_peak_centroid_width(x_data: np.ndarray, y_data: np.ndarray) -> dict:
        """
        估算峰值、背景、加权质心和FWHM宽度

        Args:
            x_data: X坐标数据
            y_data: Y值数据

        Returns:
            dict: 包含 'peak', 'bg', 'centroid', 'width' 的字典
        """
        peak_val = float(np.max(y_data))
        bg_val = float(np.mean([y_data[:len(y_data)//4].mean(), y_data[-len(y_data)//4:].mean()]))

        weights = y_data - bg_val
        weights = np.maximum(weights, 0)
        if np.sum(weights) > 0:
            weighted_centroid = float(np.sum(x_data * weights) / np.sum(weights))
        else:
            weighted_centroid = float(len(x_data) // 2)

        half_max = (peak_val + bg_val) / 2
        above_half_max = y_data >= half_max
        if np.sum(above_half_max) == 0:
            width = len(x_data) // 4
        else:
            left_idx = int(np.argmax(above_half_max))
            right_idx = int(len(y_data) - 1 - np.argmax(above_half_max[::-1]))
            width = abs(right_idx - left_idx)

        return {
            'peak': peak_val,
            'bg': bg_val,
            'centroid': weighted_centroid,
            'width': width,
        }

    def calculate2d(self, x: np.ndarray, y: np.ndarray, **params) -> np.ndarray:
        """
        计算函数值

        Args:
            x: 输入数组
            **params: 函数参数

        Returns:
            计算结果数组
        """
        def _calc():
                                
                                                                    
            cx, cy = self.get_center_x_y()
            r = np.sqrt((x - cx)**2 + (y - cy)**2) + cx
            return self.calculate1d(r, **params)
        return self._with_temp_params(params, _calc)
