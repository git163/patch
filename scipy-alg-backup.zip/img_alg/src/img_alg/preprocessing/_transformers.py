"""
数据预处理 transformers（sklearn-compatible）。
"""

import numpy as np

try:
    from sklearn.base import BaseEstimator, TransformerMixin
except ImportError:
                           
    class BaseEstimator:
        def get_params(self, deep=True):
            out = {}
            for key in self.__init__.__code__.co_varnames[1:]:
                if hasattr(self, key):
                    out[key] = getattr(self, key)
            return out

        def set_params(self, **params):
            for k, v in params.items():
                setattr(self, k, v)
            return self

    class TransformerMixin:
        def fit_transform(self, X, y=None, **fit_params):
            return self.fit(X, y).transform(X)


class ClipOutliers(BaseEstimator, TransformerMixin):
    """使用 3σ 原则裁剪异常值。"""

    def __init__(self, sigma: float = 3.0):
        self.sigma = sigma

    def fit(self, X, y=None):
        X = np.asarray(X)
        self.lower_ = float(np.mean(X) - self.sigma * np.std(X))
        self.upper_ = float(np.mean(X) + self.sigma * np.std(X))
        return self

    def transform(self, X):
        return np.clip(np.asarray(X), self.lower_, self.upper_)


class MinMaxScaler(BaseEstimator, TransformerMixin):
    """将数据归一化到 [0, 1] 范围。"""

    def __init__(self):
        pass

    def fit(self, X, y=None):
        X = np.asarray(X)
        self.data_min_ = float(np.min(X))
        self.data_max_ = float(np.max(X))
        return self

    def transform(self, X):
        X = np.asarray(X)
        rng = self.data_max_ - self.data_min_
        if rng > 0:
            return (X - self.data_min_) / rng
        return np.zeros_like(X)


class GaussianFilter(BaseEstimator, TransformerMixin):
    """应用 n*n 高斯滤波。

    Parameters
    ----------
    sigma : float
        高斯核的标准差，默认为 1.0。
    size : int
        高斯核大小 n（生成 n*n 核），默认为 2。
    mode : str
        边界处理模式，默认为 "reflect"。
    """

    def __init__(self, sigma: float = 1.0, size: int = 2, mode: str = "reflect"):
        self.sigma = sigma
        self.size = size
        self.mode = mode

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        from scipy.ndimage import gaussian_filter
                                          
                                                              
                                   
        truncate = (self.size - 1) / 2 / self.sigma if self.sigma > 0 else 1.0
        return gaussian_filter(np.asarray(X), sigma=self.sigma, mode=self.mode, truncate=truncate)
