"""
数据加载与仿真生成（sklearn.datasets 风格）。
"""

from ._io import load_csv
from ._synthetic import make_profile, make_spot, make_spot_lattice

__all__ = ["load_csv", "make_spot", "make_profile", "make_spot_lattice"]
