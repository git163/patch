"""
数据加载接口（sklearn.datasets 风格）。
"""

import numpy as np

try:
    from sklearn.utils import Bunch
except ImportError:
                
    class Bunch(dict):
        def __init__(self, **kwargs):
            super().__init__(kwargs)
            self.__dict__ = self


def load_csv(path: str) -> Bunch:
    """
    从 CSV 文件加载数据。

    会自动跳过第一行（表头），并根据数据尺寸推断为 2D 数组。
    """
    data = np.loadtxt(path, delimiter=',', skiprows=1)

                
    if data.ndim == 1:
        size = int(np.sqrt(data.size))
        if size * size == data.size:
            data = data.reshape(size, size)
        else:
                                                   
            data = data.reshape(-1, 1)
    elif data.ndim > 2:
        data = data.reshape(-1, data.shape[-1])

               
    if data.dtype == np.uint32:
        data = data.astype(np.float64)

    return Bunch(data=data, filename=path, shape=data.shape)
