"""
分析器工厂，统一管理与调度不同分析任务。
"""

from typing import Any, Dict, Optional, Tuple, Type

from .base import BaseAnalyzer


class AnalyzerFactory:
    """分析器工厂，统一管理与调度不同分析任务。"""

    _registry: Dict[str, Type[BaseAnalyzer]] = {}

    @classmethod
    def register(cls, name: str, analyzer_cls: Type[BaseAnalyzer]) -> None:
        """注册分析器类。"""
        if not issubclass(analyzer_cls, BaseAnalyzer):
            raise TypeError(
                f"Analyzer class must inherit from BaseAnalyzer, got {analyzer_cls}"
            )
        cls._registry[name] = analyzer_cls

    @classmethod
    def create(cls, name: str, **init_kwargs) -> BaseAnalyzer:
        """通过名称实例化分析器。"""
        if name not in cls._registry:
            raise ValueError(
                f"Unknown analyzer '{name}'. "
                f"Available: {list(cls._registry.keys())}"
            )
        return cls._registry[name](**init_kwargs)

    @classmethod
    def run_task(cls, name: str, params: Dict[str, Any]) -> Tuple[int, Optional[Dict[str, Any]]]:
        """直接调取分析任务：实例化并执行 process(params)。"""
        analyzer = cls.create(name)
        return analyzer.process(params)

    @classmethod
    def list_analyzers(cls) -> list[str]:
        """返回已注册的分析器名称列表。"""
        return list(cls._registry.keys())
