"""
核心模块 - 主分析器类
提供用户接口和主要处理流程
"""

import os
import numpy as np
from typing import Tuple, Dict, Any, Optional

from .core import SpotAlgorithm as AlgorithmAnalyzer
from ..base import BaseAnalyzer
from ...config.config_manager import ConfigManager
from .plotting import SpotSpotPlotter
from ...datasets import load_csv, make_spot
from ...preprocessing import ClipOutliers, MinMaxScaler, GaussianFilter
from ...utils import Logger, save_json, save_csv, save_array_csv, ensure_dir


class SpotAnalyzer(BaseAnalyzer):
    """
    图像分析系统主类

    提供简化的库函数接口，隐藏复杂实现细节
    """

    def __init__(self, config_file: Optional[str] = None, **kwargs):
        super().__init__()
        """
        初始化分析器

        Args:
            config_file: 配置文件路径
            **kwargs: 覆盖配置文件的参数
                      例如: data_source='real', image_size=256, sample_config_size=256
        """
                  
        self.config_manager = ConfigManager(config_file)

                   
        if kwargs:
            self.config_manager.update_with_kwargs(kwargs)

              
        is_valid, error_msg = self.config_manager.validate_config()
        if not is_valid:
            raise ValueError(f"Config validation failed: {error_msg}")

                 
        self.algorithm_analyzer = AlgorithmAnalyzer()
        self.plotter = SpotSpotPlotter(self.config_manager.get_visualization_config())

              
        self.results = {}

    def _do_process(self) -> Tuple[int, Optional[Dict[str, Any]]]:
        """
        主处理逻辑，由基类 process(params) 统一调度。

        运行时参数通过 self.get_param(key) 从参数字典中读取：
            - input_file: 输入文件（仅在真实数据模式需要）
            - image_size: 图像尺寸n（n > 64）
            - sample_config_size: 采样范围（≤ image_size）

        Returns:
            tuple: (error_code, results)
                   error_code: 0=成功, 1=文件错误, 2=数据错误, 3=算法错误, 4=配置错误
        """
        input_file = self.get_param("input_file")
        image_size = self.get_param("image_size")
        sample_config_size = self.get_param("sample_config_size")

        if not self._prepare_config(image_size, sample_config_size):
            return 4, None

        raw_data = self._load_data(input_file)
        if raw_data is None:
            return 1, None

        processed_data = self._apply_preprocessing(raw_data)
        center = self._analyze_center(processed_data)
        if center is None:
            return 3, None

        edge_results = self._analyze_edges(processed_data, center)
        results = self._build_results(raw_data, processed_data, center, edge_results)

        return 0, results

    def _prepare_config(self, image_size: Optional[int], sample_config_size: Optional[int]) -> bool:
        """更新并验证运行时配置"""
        if image_size:
            self.config_manager.update_with_kwargs({'basic_config.image_size': image_size})
        if sample_config_size:
            self.config_manager.update_with_kwargs({'basic_config.sample_config_size': sample_config_size})

        is_valid, error_msg = self.config_manager.validate_config()
        if not is_valid:
            Logger.error("Config error: %s", error_msg)
            return False
        return True

    def _load_data(self, input_file: Optional[str]) -> Optional[np.ndarray]:
        """根据配置加载或生成原始数据"""
        basic_config = self.config_manager.get_basic_config()

        if basic_config['data_source'] == 'simulation':
            return self._generate_simulation_raw_data(basic_config)

        return self._load_real_data(input_file, basic_config)

    def _generate_simulation_raw_data(self, basic_config: Dict[str, Any]) -> np.ndarray:
        """生成仿真数据"""
        sim_config = self.config_manager.get_simulation_config()
        spot_params = sim_config['spot_params'].copy()

        actual_image_size = basic_config['image_size']
        scale_factor = actual_image_size / 256.0
        spot_params['center'] = [
            spot_params['center'][0] * scale_factor,
            spot_params['center'][1] * scale_factor
        ]

        noise_level = sim_config.get('noise_level', 0.0)
        save_image = basic_config.get('save_simulation_images', True)

        return self._generate_simulation_data(
            image_size=actual_image_size,
            spot_params=spot_params,
            noise_level=noise_level,
            save_image=save_image
        )

    def _load_real_data(self, input_file: Optional[str], basic_config: Dict[str, Any]) -> Optional[np.ndarray]:
        """从文件加载真实数据"""
        input_file = input_file or self._find_default_input_file()
        if not input_file:
            return None

        try:
            bunch = load_csv(input_file)
            raw_data = bunch.data
        except Exception as e:
            Logger.error("Data loading error: %s", e)
            return None

        actual_image_size = raw_data.shape[0]
        self._save_original_data_plot(raw_data, actual_image_size)
        return raw_data

    def _find_default_input_file(self) -> Optional[str]:
        """自动查找默认输入文件"""
        origin_csv_dir = "data/origin_csv"
        os.makedirs(origin_csv_dir, exist_ok=True)

        if not os.path.isdir(origin_csv_dir):
            Logger.error("Real data mode requires input_file")
            return None

        csv_files = [
            f for f in os.listdir(origin_csv_dir)
            if f.lower().startswith('origin_') and f.lower().endswith('.csv')
        ]
        if not csv_files:
            Logger.error("Real data mode requires input_file (must start with origin_)")
            return None

        input_file = os.path.join(origin_csv_dir, csv_files[0])
        Logger.info("No input file specified, auto-using: %s", input_file)
        return input_file

    def _save_original_data_plot(self, raw_data: np.ndarray, image_size: int) -> None:
        """保存原始数据可视化图像"""
        from ...visualization.plotting import create_2d_plot
        from .center import center_of_mass
        output_file = os.path.join("data/origin_csv", f"original_data_{image_size}x{image_size}.png")
        centroid = center_of_mass(raw_data)
        create_2d_plot(raw_data, title=f"{image_size}×{image_size})", output_file=output_file, centroid=centroid)

    def _apply_preprocessing(self, raw_data: np.ndarray) -> np.ndarray:
        """应用数据预处理"""
        algorithm_config = self.config_manager.get_algorithm_config()
        if algorithm_config.get('gaussian_filter', True):
            return self._preprocess_data(raw_data)
        return raw_data.copy()

    def _analyze_center(self, processed_data: np.ndarray) -> Optional[Tuple[float, float]]:
        """光斑中心定位"""
        basic_config = self.config_manager.get_basic_config()
        algorithm_config = self.config_manager.get_algorithm_config()
        center_method = basic_config['center_method']
        num_lines = basic_config.get('num_sample_lines', 3)
        line_max_interval = algorithm_config.get('line_max_interval', 5)

        try:
            return self.algorithm_analyzer.analyze_center(
                data=processed_data,
                method=center_method,
                num_lines=num_lines,
                line_max_interval=line_max_interval
            )
        except Exception as e:
            Logger.error("Center localization failed: %s", e)
            return None

    def _analyze_edges(self, processed_data: np.ndarray, center: Tuple[float, float]) -> Dict[str, Any]:
        """边缘模糊分析"""
        directions = ['0', '90', '45', '135']
        center_x, center_y = center
        return self.algorithm_analyzer.analyze_edge_blur(
            processed_data, center_x, center_y, directions
        )

    def _build_results(self,
                       raw_data: np.ndarray,
                       processed_data: np.ndarray,
                       center: Tuple[float, float],
                       edge_results: Dict[str, Any]) -> Dict[str, Any]:
        """构建结果字典"""
        return {
            'original_data': raw_data.tolist(),
            'processed_data': processed_data.tolist(),
            'center': list(center),
            'edge_analysis': edge_results,
            'config': self.config_manager.config.copy(),
            'metadata': {
                'image_size': processed_data.shape,
                'processing_time': None,
                'algorithm_version': '0.1.0'
            }
        }

    def _generate_simulation_data(self, image_size, spot_params, noise_level, save_image):
        """内部方法：生成仿真数据（委托给 datasets.make_spot）"""
        center_x, center_y = spot_params['center']
        radius = spot_params['radius']
        k = spot_params['intensity_k']
        sigma1 = spot_params.get('sigma1', 3.0)
        sigma2 = spot_params.get('sigma2', 4.0)
        bg = spot_params.get('background', 10.0)
        slope = spot_params.get('slope', 0)

        output_path = None
        if save_image:
            output_path = self._simulation_file_path(radius, k, sigma1, sigma2, '.csv')

        intensity = make_spot(
            model='bilateral_rect',
            image_size=image_size,
            noise_level=noise_level,
            output_path=output_path,
            k=k,
            cx=center_x,
            cy=center_y,
            R=radius,
            sigma1=sigma1,
            sigma2=sigma2,
            bg=bg,
            slope=slope,
        )

        if save_image:
            self._save_simulation_image(intensity, radius, k, sigma1, sigma2)

        return intensity

    @staticmethod
    def _simulation_file_path(radius, k, sigma1, sigma2, extension):
        """生成仿真文件路径"""
        output_dir = "data/image/simulation"
        os.makedirs(output_dir, exist_ok=True)
        return os.path.join(output_dir, f"simulation_R{radius}_k{k}_σ1{sigma1}_σ2{sigma2}{extension}")

    def _save_simulation_image(self, intensity, radius, k, sigma1, sigma2):
        """保存仿真数据对应的图像"""
        from ...visualization.plotting import create_2d_plot
        from .center import center_of_mass
        image_output_file = self._simulation_file_path(radius, k, sigma1, sigma2, '.png')
        centroid = center_of_mass(intensity)

        create_2d_plot(
            intensity,
            title=f"Simulated image (R={radius}, k={k}, σ1={sigma1}, σ2={sigma2})",
            output_file=image_output_file,
            centroid=centroid,
        )

    def _preprocess_data(self, data: np.ndarray) -> np.ndarray:
        """内部方法：数据预处理（委托给 preprocessing transformers）"""
        processed_data = data.astype(np.float64)
        processed_data = ClipOutliers(sigma=3.0).fit_transform(processed_data)
        processed_data = MinMaxScaler().fit_transform(processed_data)
        processed_data = GaussianFilter(sigma=1.0).fit_transform(processed_data)
        return processed_data

    def plot_results(self, results: Optional[Dict[str, Any]] = None) -> None:
        """结果可视化"""
        if results is None:
            results = self.results

        if not results:
            Logger.warning("No results to display")
            return

                
        data = np.array(results['processed_data'])
        center_x, center_y = results['center']
        edge_results = results['edge_analysis']

                
        output_dir = self.config_manager.get('basic_config.output_dir', 'results')
        os.makedirs(output_dir, exist_ok=True)

                
        self.plotter.plot_comprehensive_results(
            data,
            center_x,
            center_y,
            edge_results,
            output_dir
        )

        Logger.info("Results saved to: %s", output_dir)

    def save_results(self, results: Optional[Dict[str, Any]] = None, output_dir: Optional[str] = None, format_type: str = 'csv') -> bool:
        """
        保存结果到文件

        Args:
            results: 要保存的结果，如果为None则使用内部结果
            output_dir: 输出目录，如果为None则使用配置文件中的设置
            format_type: 保存格式类型（预留参数）

        Returns:
            bool: 是否成功保存
        """
        if results is None:
            results = self.results

        if not results:
            Logger.warning("No results to save")
            return False

        output_dir = output_dir or self.config_manager.get('basic_config.output_dir', 'results')
        if output_dir is None:
            output_dir = 'results'

        try:
            ensure_dir(os.path.join(output_dir, ".placeholder"))

            for key, value in results.items():
                if not self._save_result_item(key, value.copy(), output_dir):
                    return False

                        
            summary_path = os.path.join(output_dir, "analysis_summary.txt")
            self.plotter.save_summary_report(results, summary_path)

            Logger.info("All results saved to %s", output_dir)
            return True

        except Exception as e:
            Logger.error("Result saving failed: %s", e)
            return False

    def _save_result_item(self, key: str, value: Any, output_dir: str) -> bool:
        """保存单个结果项，按数据类型分发到对应保存方法"""
        if key in ['original_data', 'processed_data']:
            return self._save_array_result(key, value, output_dir)
        elif key == 'edge_analysis' and isinstance(value, dict):
            return self._save_edge_analysis(value, output_dir)
        elif isinstance(value, dict):
            return self._save_dict_result(key, value, output_dir)
        return True

    def _save_array_result(self, key: str, value: Any, output_dir: str) -> bool:
        """将数组结果保存为CSV"""
        filename = os.path.join(output_dir, f"{key}.csv")
        try:
            save_array_csv(value, filename)
            Logger.info("Saved large array %s to %s", key, filename)
            return True
        except Exception as e:
            Logger.error("Failed to save CSV file %s: %s", filename, e)
            return False

    def _save_edge_analysis(self, value: Dict[str, Any], output_dir: str) -> bool:
        """保存完整的 edge_analysis 结果（JSON、汇总CSV及各角度CSV）"""
        json_filename = os.path.join(output_dir, "edge_analysis.json")
        try:
            self._save_edge_analysis_summary(value, output_dir)
            save_json(value, json_filename)
            self._save_edge_angle_data(value, output_dir)
            Logger.info("Saved edge_analysis dict to %s", json_filename)
            return True
        except Exception as e:
            Logger.error("Failed to save edge_analysis to %s: %s", json_filename, e)
            return False

    def _save_edge_analysis_summary(self, value: Dict[str, Any], output_dir: str) -> None:
        """将 edge_analysis 的拟合参数汇总保存为CSV"""
        import pandas as pd
        rows = []
        for angle_data in value.values():
            angle_data = angle_data.copy()
            angle_data.pop('line_data', None)
            angle_data.pop('original_data', None)
            fit = angle_data['fit_params']
            row = {
                'model_type': fit['model_type'],
                'success': fit['success'],
                'r_squared': fit['r_squared'],
                'center': fit['center'],
                'angle': angle_data['angles'][0],
                **fit['parameters']
            }
            rows.append(row)

        df = pd.DataFrame(rows).round(1)
        df.to_csv(os.path.join(output_dir, "edge_analysis.csv"), sep="\t")

    def _save_edge_angle_data(self, value: Dict[str, Any], output_dir: str) -> None:
        """将各角度的 line_data 和 original_data 分别保存为CSV"""
        line_dir = os.path.join(output_dir, "line")
        ensure_dir(line_dir)

        for angle_key, angle_data in value.items():
            if not angle_key.replace('.', '').replace('-', '').isdigit():
                continue
            angle = float(angle_key)
            self._save_single_angle_data(angle_data, angle, line_dir, 'line_data')
            self._save_single_angle_data(angle_data, angle, line_dir, 'original_data')

    def _save_single_angle_data(self, angle_data: Dict[str, Any], angle: float, line_dir: str, data_type: str) -> None:
        """保存单个角度的数据到CSV"""
        filename = os.path.join(line_dir, f"{data_type}_{angle:.0f}deg.csv")
        try:
            rows = [[i, v] for i, v in enumerate(angle_data.get(data_type, []))]
            save_csv(rows, filename, headers=['index', data_type])
            Logger.info("Saved %.0f deg %s to %s", angle, data_type, os.path.basename(filename))
        except Exception as e:
            Logger.error("Failed to save %s CSV file %s: %s", data_type, filename, e)

    def _save_dict_result(self, key: str, value: Dict[str, Any], output_dir: str) -> bool:
        """将普通字典结果保存为JSON"""
        filename = os.path.join(output_dir, f"{key}.json")
        try:
            save_json(value, filename)
            Logger.info("Saved dict %s to %s", key, filename)
            return True
        except Exception as e:
            Logger.error("Failed to save JSON file %s: %s", filename, e)
            return False

    def get_fitting_plots(self, direction: str = 'all') -> Optional[Dict[str, Any]]:
        """
        获取拟合结果图片

        Args:
            direction: 'all', '0', '90', '45', '135', etc.

        Returns:
            图片数据或文件路径信息
        """
        if not self.results:
            Logger.warning("No analysis results available")
            return None

        edge_analysis = self.results['edge_analysis']

        if direction == 'all':
            return {'directions': list(edge_analysis.keys()), 'count': len(edge_analysis)}

        if direction not in edge_analysis:
            return {
                'available_directions': list(edge_analysis.keys()),
                'requested_direction': direction,
                'status': 'invalid_direction'
            }

        result = edge_analysis[direction]
        fit_params = result['fit_params']

        if fit_params['model_type'] == 'failed':
            return {
                'direction': direction,
                'error': fit_params['error'],
                'status': 'fitting_failed'
            }

        return {
            'direction': direction,
            'angles': result['angles'],
            'model_type': fit_params['model_type'],
            'r_squared': fit_params['r_squared'],
            'parameters': {
                'R': fit_params['R'],
                'k': fit_params['k'],
                'x0': fit_params['x0'],
                'bg': fit_params['bg']
            }
        }

    @classmethod
    def quick_start(cls, **kwargs):
        """
        快速启动方法，提供最简单的接口

        Args:
            **kwargs: 配置参数

        Returns:
            SpotAnalyzer实例
        """
                     
        analyzer = cls(**kwargs)

                          
        if 'data_source' not in kwargs and 'input_file' not in kwargs:
            analyzer.config_manager.update_with_kwargs({
                'basic_config.data_source': 'simulation'
            })

        return analyzer

