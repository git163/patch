from typing import Tuple, Optional
import numpy as np

from ...models.erf import BilateralRectEstimator
from ..common.geometry import extract_lines_through_center
from ..common.signal import estimate_background


def _fit_bilateral_center(x: np.ndarray, y: np.ndarray, min_r2: float = 0.8) -> Optional[float]:
    """使用 BilateralRect 拟合 1D 剖面并返回中心位置（在 x 坐标系下）。"""
    estimator = BilateralRectEstimator()
    try:
        estimator.fit(x, y)
        if (
            estimator.success_
            and estimator.center_ is not None
            and estimator.diagnostics_.get("r_squared", 0.0) >= min_r2
        ):
            return float(estimator.center_)
    except Exception:
        pass
    return None


def center_of_mass(data: np.ndarray, use_erf_fit = True) -> Tuple[float, float]:
    """质心法定位（基于直方图峰值估计背景，自适应亮斑/暗斑）

    流程：
    1. 先用基于直方图背景估计的阈值质心法计算初始中心。
    2. 以初始中心为起点，分别沿 0°（水平）和 90°（垂直）采样直线数据。
    3. 对两条采样直线做双边 erf 拟合，若拟合成功则用拟合得到的 x0 修正中心坐标。
    """
    if data.size == 0 or np.sum(data) == 0:
        return data.shape[1] // 2, data.shape[0] // 2

    bg = estimate_background(data)
    deviation = np.abs(data - bg)
    threshold = np.percentile(deviation, 90)
    mask = deviation >= threshold
    if not np.any(mask):
        return data.shape[1] // 2, data.shape[0] // 2

    rows, cols = np.meshgrid(np.arange(data.shape[0]), np.arange(data.shape[1]), indexing='ij')
    total_weight = np.sum(deviation[mask])
    if total_weight == 0:
        return data.shape[1] // 2, data.shape[0] // 2

    centroid_y = np.sum(rows[mask] * deviation[mask]) / total_weight
    centroid_x = np.sum(cols[mask] * deviation[mask]) / total_weight
    cx = float(centroid_x)
    cy = float(centroid_y)

    if not use_erf_fit:
        return cx, cy

                             
               
    try:
        line_h, _ = extract_lines_through_center(data, cx, cy, '0')
        if line_h.size > 5:
            n = line_h.size // 2
            x_fit = np.arange(line_h.size, dtype=float)
            x0_fit = _fit_bilateral_center(x_fit, line_h)
            if x0_fit is not None:
                offset = x0_fit - n
                new_cx = cx + offset
                if 0 <= new_cx <= data.shape[1] - 1:
                    cx = new_cx
    except Exception:
        pass

                           
    try:
        line_v, _ = extract_lines_through_center(data, cx, cy, '90')
        if line_v.size > 5:
            n = line_v.size // 2
            x_fit = np.arange(line_v.size, dtype=float)
            y0_fit = _fit_bilateral_center(x_fit, line_v)
            if y0_fit is not None:
                offset = y0_fit - n
                new_cy = cy + offset
                if 0 <= new_cy <= data.shape[0] - 1:
                    cy = new_cy
    except Exception:
        pass

    return cx, cy
