"""
算法处理层模块
负责光斑中心定位、边缘模糊分析和ERF模型拟合
"""

from .base import BaseAnalyzer
from .factory import AnalyzerFactory
from .spot import SpotAnalyzer, SpotAlgorithm, center_of_mass
from .spot_lattice import SpotSpotLatticeAnalyzer, LatticeEdgeAlgorithm
from .common.signal import detect_signal_type, estimate_background

__all__ = [
    "BaseAnalyzer",
    "AnalyzerFactory",
    "SpotAnalyzer",
    "SpotAlgorithm",
    "SpotSpotLatticeAnalyzer",
    "LatticeEdgeAlgorithm",
    "detect_signal_type",
    "estimate_background",
    "center_of_mass",
]

                                                                                
AnalyzerFactory.register("spot", SpotAnalyzer)
AnalyzerFactory.register("lattice", SpotSpotLatticeAnalyzer)
