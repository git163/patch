
import numpy as np


def _parse_direction(direction: str) -> float:
    """将方向字符串转换为角度数值。"""
    if direction == '0':
        return 0.0
    if direction == '90':
        return 90.0
    return float(direction)


def extract_lines_through_center(data: np.ndarray,
                                center_x: float,
                                center_y: float,
                                direction: str,
                                num_samples: int = -1) -> tuple:
    """
    提取穿过中心的线数据（通用方法）- 统一处理所有角度

    Args:
        data: 输入数据
        center_x: 中心X坐标
        center_y: 中心Y坐标
        direction: 方向 ('0', '45', '90', '135', 或其他角度)
        num_samples: 采样数量 (2n+1)

    Returns:
        tuple: (line_datas, angles)
            line_datas: 线数据列表（每个元素是一条线上的2n+1个采样点）
            angles: 对应的角度列表
    """
    if num_samples < 0:
        num_samples = min(data.shape[0], data.shape[1]) // 2 - 1

    angle_deg = _parse_direction(direction)
    angle_rad = np.deg2rad(angle_deg)
    dx = np.cos(angle_rad)
    dy = np.sin(angle_rad)

    n = num_samples
    line_data = []
    for i in range(-n, n + 1):
        x = center_x + i * dx
        y = center_y + i * dy
        x_idx = int(np.clip(np.round(x), 0, data.shape[1] - 1))
        y_idx = int(np.clip(np.round(y), 0, data.shape[0] - 1))
        if 0 <= y_idx < data.shape[0] and 0 <= x_idx < data.shape[1]:
            line_data.append(data[y_idx, x_idx])

    return np.array(line_data), [angle_deg]


def extract_ray_from_center(data: np.ndarray,
                            center_x: float,
                            center_y: float,
                            direction: str,
                            num_samples: int = -1) -> tuple:
    """
    从中心点出发，沿指定方向采样 n+1 个点（线性插值）

    Args:
        data: 输入数据
        center_x: 中心X坐标
        center_y: 中心Y坐标
        direction: 方向 ('0', '45', '90', '135', 或其他角度)
        num_samples: 采样数量（不含中心点，实际返回 n+1 个点）

    Returns:
        tuple: (line_datas, angles)
            line_datas: 线数据列表（n+1个采样点）
            angles: 对应的角度列表
    """
    if num_samples < 0:
        num_samples = max(data.shape[0], data.shape[1])

    angle_deg = _parse_direction(direction)
    angle_rad = np.deg2rad(angle_deg)
    dx = np.cos(angle_rad)
    dy = np.sin(angle_rad)

    n = num_samples
    line_data = []
    for i in range(1, n + 2):
        x = center_x + i * dx
        y = center_y + i * dy
        value = bilinear_interpolate(data, y, x)
        line_data.append(value)

    return [np.array(line_data)], [angle_deg]


def _bilinear_weights(x: float, y: float) -> tuple:
    """计算双线性插值的整数角点坐标和权重。"""
    x0 = int(np.floor(x))
    y0 = int(np.floor(y))
    fx = x - x0
    fy = y - y0
    w00 = (1 - fx) * (1 - fy)
    w01 = fx * (1 - fy)
    w10 = (1 - fx) * fy
    w11 = fx * fy
    return x0, y0, w00, w01, w10, w11


def _interpolate_scalar(v00, v01, v10, v11, w00, w01, w10, w11):
    """对单个像素或通道进行双线性插值。"""
    return v00 * w00 + v01 * w01 + v10 * w10 + v11 * w11


def bilinear_interpolate(data: np.ndarray, y: float, x: float) -> float:
    """
    双线性插值

    Args:
        data: 输入数据 (H, W) 或 (H, W, C)
        y: Y坐标（行）
        x: X坐标（列）

    Returns:
        插值后的值
    """
    h, w = data.shape[:2]
    if x < 0 or x > w - 1 or y < 0 or y > h - 1:
        return 0.0

    x0, y0, w00, w01, w10, w11 = _bilinear_weights(x, y)
    x1 = min(x0 + 1, w - 1)
    y1 = min(y0 + 1, h - 1)
    x0 = np.clip(x0, 0, w - 1)
    y0 = np.clip(y0, 0, h - 1)

    if data.ndim == 2:
        return _interpolate_scalar(
            data[y0, x0], data[y0, x1], data[y1, x0], data[y1, x1],
            w00, w01, w10, w11
        )

                 
    value = np.empty(data.shape[2:])
    for c in range(data.shape[2]):
        value[c] = _interpolate_scalar(
            data[y0, x0, c], data[y0, x1, c], data[y1, x0, c], data[y1, x1, c],
            w00, w01, w10, w11
        )
    return value
