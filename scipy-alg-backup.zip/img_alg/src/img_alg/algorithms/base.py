"""
分析器抽象基类，定义统一入口与公共行为。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple

from ..utils import Logger


class BaseAnalyzer(ABC):
    """所有分析器的抽象基类，负责统一入口与异常处理。"""

    def __init__(self):
        self.params: Dict[str, Any] = {}
        self.results: Dict[str, Any] = {}

    def setup(self, params: Dict[str, Any]) -> None:
        """存储分析任务参数。子类可在 super().setup() 后追加自定义初始化。"""
        self.params = dict(params) if params else {}
        self.results = {}

    def get_param(self, key: str, default: Any = None) -> Any:
        return self.params.get(key, default)

    def set_param(self, key: str, value: Any) -> None:
        self.params[key] = value

    def get_mode(self) -> str:
        return self.get_param("mode", "simulation")

    def process(self, params: Optional[Dict[str, Any]] = None) -> Tuple[int, Optional[Dict[str, Any]]]:
        """
        统一入口模板方法。负责 setup + 统一异常捕获。

        Returns
        -------
        tuple
            (error_code, results)
            error_code: 0=success, 1=file error, 2=data error, 3=algorithm error, 4=config error
        """
        self.setup(params)
        try:
            code, result = self._do_process()
            self.results = result if result else {}
            return code, result
        except ValueError as e:
            Logger.error("Data error: %s", e)
            return 2, None
        except FileNotFoundError as e:
            Logger.error("File error: %s", e)
            return 1, None
        except Exception as e:
            Logger.error("Algorithm error: %s", e)
            return 3, None

    @abstractmethod
    def _do_process(self) -> Tuple[int, Optional[Dict[str, Any]]]:
        """子类必须实现的核心分析逻辑，从 self.params 中读取参数。"""
        raise NotImplementedError
