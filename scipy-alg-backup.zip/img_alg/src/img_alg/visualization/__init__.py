"""
可视化展示层模块
负责结果可视化和图表绘制
"""

import matplotlib.font_manager as fm
import matplotlib.pyplot as plt

                  
_CANDIDATE_FONTS = [
    "PingFang SC",
    "PingFang HK",
    "Hiragino Sans GB",
    "STHeiti",
    ".AppleSystemUIFont",
    "Microsoft YaHei",
    "SimHei",
    "SimSun",
]

                  
_available_fonts = [f.name for f in fm.fontManager.ttflist]
_usable_fonts = [name for name in _CANDIDATE_FONTS if name in _available_fonts]

                                          
if _usable_fonts:
    plt.rcParams["font.sans-serif"] = _usable_fonts
    plt.rcParams["axes.unicode_minus"] = False
else:
    import warnings

    warnings.warn(
        "No Chinese font found on this system. Chinese characters may not render correctly.",
        UserWarning,
        stacklevel=2,
    )