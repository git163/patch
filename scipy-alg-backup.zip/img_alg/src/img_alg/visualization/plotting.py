import matplotlib.pyplot as plt
import numpy as np
from img_alg.utils import Logger, save_figure


def create_plot_1d(func, x_range=(0, 100), title=None, output_file=None):
    """通用绘图函数"""
    fig, ax = plt.subplots(figsize=(10, 6))

    x = np.linspace(x_range[0], x_range[1], 1000)
    y = func.calculate1d(x)

    ax.plot(x, y, lw=2.5, label=f"{func.name}")

             
    ax.grid(True, alpha=0.3)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    if title:
        ax.set_title(title)
    else:
        ax.set_title(f"{func.name} Function")
    ax.legend()

    if output_file:
        save_figure(fig, output_file, dpi=150)
        Logger.info("1D image saved: %s", output_file)
    else:
        plt.close(fig)


def create_2d_plot(
    data,
    title=None,
    output_file=None,
    center_origin=True,
    centroid=None,
    show_centroid=True,
):
    """创建2D数据可视化

    Args:
        data: 2D数组数据
        title: 图像标题
        output_file: 输出文件路径
        center_origin: 是否将原点设在图像中心。True时坐标范围为[-range/2, range/2]，
                      False时坐标范围为[0, range]
        centroid: 可选，质心坐标 (x, y)。若提供且 show_centroid=True，则在图上标注。
        show_centroid: 是否标注质心。当 centroid 为 None 时，不会进行任何计算。
    """
    fig, ax = plt.subplots(figsize=(8, 6))

            
    ny, nx = data.shape

    if center_origin:
                                    
        extent = (-nx / 2, nx / 2, -ny / 2, ny / 2)
    else:
                         
        extent = (0, nx, 0, ny)

                         
    im = ax.imshow(data, cmap="YlGnBu", origin="lower", extent=extent)
    ax.set_title(title or "2D Simulation Result")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")

                  
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.7)
    ax.axvline(x=0, color='gray', linestyle='--', linewidth=0.8, alpha=0.7)

    if centroid is not None and show_centroid:
        centroid_x, centroid_y = centroid
        if center_origin:
            centroid_x_plot = centroid_x - nx / 2
            centroid_y_plot = centroid_y - ny / 2
        else:
            centroid_x_plot = centroid_x
            centroid_y_plot = centroid_y

        ax.plot(
            centroid_x_plot,
            centroid_y_plot,
            'r*',
            markersize=15,
            label=f'Centroid ({centroid_x_plot:.1f}, {centroid_y_plot:.1f})',
        )
        ax.legend()

           
    add_colorbar(im, ax)

    if output_file:
        save_figure(fig, output_file, dpi=150)
        Logger.info("2D image saved: %s", output_file)
    else:
        plt.close(fig)


def create_comparison_plot(
    functions, x_range=(0, 100), title="Function Comparison", output_file=None, colors=None
):
    """创建多个函数的对比图"""

    fig, ax = plt.subplots(figsize=(12, 8))

    default_colors = ["b", "r", "g", "m", "c", "y"]
    plot_colors = colors if colors is not None else default_colors
    x = np.linspace(x_range[0], x_range[1], 1000)
    for i, func in enumerate(functions):
        y = func.calculate1d(x)
        color = plot_colors[i % len(plot_colors)]
        ax.plot(x, y, lw=2, label=f"{func.name}", color=color)

    ax.grid(True, alpha=0.3)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_title(title)
    ax.legend()
    ax.set_xlim(x_range)

                     
    if output_file:
        save_figure(fig, output_file, dpi=150)
        Logger.info("Comparison plot saved: %s", output_file)
    else:
        plt.close(fig)


def add_colorbar(im, ax, label=None):
    """在指定 axes 上为图像对象添加统一风格的颜色条"""
    cbar = plt.colorbar(im, ax=ax)
    if label:
        cbar.set_label(label)
    return cbar


def create_subplots_grid(n_plots, max_cols=3, figsize_per_plot=(6, 4)):
    """创建动态行列的多子图网格，并返回 fig 与扁平化的 axes 列表。

    Args:
        n_plots: 子图总数
        max_cols: 每行最大列数
        figsize_per_plot: 单个子图的尺寸 (width, height)

    Returns:
        tuple: (fig, axes_list)
    """
    cols = min(n_plots, max_cols)
    rows = (n_plots + cols - 1) // cols

    fig, axes = plt.subplots(rows, cols, figsize=(figsize_per_plot[0] * cols, figsize_per_plot[1] * rows))

    if n_plots == 1:
        axes = [axes]
    else:
        axes = axes.flatten()

             
    for idx in range(n_plots, len(axes)):
        axes[idx].set_visible(False)

    return fig, axes
