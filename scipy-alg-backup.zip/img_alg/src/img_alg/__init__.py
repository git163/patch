"""
图像分析系统 (Image Algorithm)

一个用于图像分析的Python库，提供精确的光斑特性分析和ERF模型拟合功能。

主要功能:
- 数据加载和预处理（支持真实数据和仿真数据）
- 光斑中心精确定位（质心法+剖面法）
- 边缘模糊分析（双边/单边erf模型）
- 结果可视化展示
- 简化参数配置

示例用法:
    >>> from img_alg import SpotAnalyzer
    >>> analyzer = SpotAnalyzer(data_source='simulation', image_size=256)
    >>> error_code, results = analyzer.process()
    >>> if error_code == 0:
    ...     analyzer.plot_results()
    ...     analyzer.save_results()

Author: Dev Team
Version: 0.1.0
"""

from .core import SpotAnalyzer

__all__ = ['SpotAnalyzer']
__version__ = "0.1.0"
__author__ = "Dev Team"