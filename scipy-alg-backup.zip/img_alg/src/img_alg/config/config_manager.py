"""
配置管理模块
负责配置文件读取和管理
"""

import os,json
from typing import Dict, Any, Optional, Tuple

from ..utils import Logger, save_json, ensure_dir


class ConfigManager:
    """配置管理器"""

    DEFAULT_CONFIG = {
        "basic_config": {
            "data_source": "simulation",                    
            "image_size": 256,                  
            "sample_config_size": 12,           
            "center_method": "auto",                             
            "output_dir": "results/"
        },
        "algorithm_config": {
            "gaussian_filter": True,
            "num_sample_lines": 3,
            "line_max_interval": 5
        },
        "visualization_config": {
            "colormap": "YlGnBu",
            "show_profile": True,
            "save_fitting_plots": False,
            "image_dpi": 150
        },
        "simulation_config": {
            "model_type": "erf",                 
            "spot_params": {
                "center": [64, 153],
                "radius": 46,
                "intensity_k": 5000,
                "sigma1": 10,
                "sigma2": 10,
                "background": 20,
                "slope": 1
            },
            "noise_level": 1
        }
    }

    def __init__(self, config_file: Optional[str] = None, **kwargs):
        """
        初始化配置管理器

        Args:
            config_file: 配置文件路径
            **kwargs: 覆盖配置文件的参数
        """
        self.config = self.DEFAULT_CONFIG.copy()

                
        if config_file and os.path.exists(config_file):
            self.load_from_file(config_file)

                   
        if kwargs:
            self.update_with_kwargs(kwargs)

    def load_from_file(self, config_file: str) -> bool:
        """
        从文件加载配置

        Args:
            config_file: 配置文件路径

        Returns:
            bool: 是否成功加载
        """
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                file_config = json.loads(f.read()) or {}

                          
            self._merge_configs(file_config)
            return True

        except Exception as e:
            Logger.error("Config file loading failed: %s", e)
            return False

    def update_with_kwargs(self, kwargs: Dict[str, Any]) -> None:
        """
        使用关键字参数更新配置，支持多段路径

        Args:
            kwargs: 参数字典，key 支持点号分隔的多段路径
                    如: 'basic_config.image_size'
                        'algorithm_config.gaussian_filter'
        """
        for key, value in kwargs.items():
                                 
            self._set_nested_value(self.config, key.split('.'), value)

    def _merge_configs(self, new_config: Dict[str, Any]) -> None:
        """
        合并配置文件

        Args:
            new_config: 新配置字典
        """
        for section_name, section_data in new_config.items():
            if section_name in self.config:
                if isinstance(section_data, dict) and isinstance(self.config[section_name], dict):
                    self.config[section_name].update(section_data)
                else:
                    self.config[section_name] = section_data
            else:
                self.config[section_name] = section_data

    @staticmethod
    def _set_nested_value(config_dict: Dict[str, Any], keys: list, value: Any) -> None:
        """
        设置嵌套字典中的值

        Args:
            config_dict: 配置字典
            keys: 键列表
            value: 值
        """
        current = config_dict
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        current[keys[-1]] = value

    def get(self, key_path: str, default=None) -> Any:
        """
        获取配置值

        Args:
            key_path: 键的路径，支持点号分隔（如 'basic_config.image_size'）
            default: 默认值

        Returns:
            配置值
        """
        try:
            keys = key_path.split('.')
            value = self.config
            for key in keys:
                if isinstance(value, dict) and key in value:
                    value = value[key]
                else:
                    return default
            return value
        except Exception:
            return default

    def validate_config(self) -> Tuple[bool, str]:
        """
        验证配置有效性

        Returns:
            tuple: (是否有效, 错误信息)
        """
        basic_config = self.get('basic_config')

                
        required_fields = ['data_source', 'image_size', 'sample_config_size']
        for field in required_fields:
            if field not in basic_config or basic_config[field] is None:
                return False, f"Missing required config item: {field}"

               
        if basic_config['data_source'] not in ['real', 'simulation']:
            return False, "data_source must be 'real' or 'simulation'"

                
        image_size = basic_config['image_size']
        if not isinstance(image_size, (int, float)) or image_size <= 64:
            return False, "image_size must be greater than 64"

                
        sample_size = basic_config['sample_config_size']
        if not isinstance(sample_size, (int, float)) or sample_size > image_size:
            return False, "sample_config_size cannot be greater than image_size"

                
        if basic_config['data_source'] == 'simulation':
            sim_config = self.get('simulation_config')
            spot_params = sim_config.get('spot_params', {})

                    
            if 'center' not in spot_params:
                return False, "Simulation mode requires center parameter"
            if len(spot_params['center']) != 2:
                return False, "center parameter must be a list of length 2"

        return True, "Config is valid"

    def save_to_file(self, output_path: str) -> bool:
        """
        保存配置到文件

        Args:
            output_path: 输出文件路径

        Returns:
            bool: 是否成功保存
        """
        try:
            save_json(self.config, output_path)
            return True
        except Exception as e:
            Logger.error("Config save failed: %s", e)
            return False

    def get_basic_config(self) -> Dict[str, Any]:
        """获取基础配置"""
        return self.config.get('basic_config', {})

    def get_algorithm_config(self) -> Dict[str, Any]:
        """获取算法配置"""
        return self.config.get('algorithm_config', {})

    def get_visualization_config(self) -> Dict[str, Any]:
        """获取可视化配置"""
        return self.config.get('visualization_config', {})

    def get_simulation_config(self) -> Dict[str, Any]:
        """获取仿真配置"""
        return self.config.get('simulation_config', {})