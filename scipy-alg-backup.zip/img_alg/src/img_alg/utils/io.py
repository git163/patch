"""统一 I/O 工具模块

提供目录创建、JSON/CSV 序列化、图像保存等常用文件操作，
消除项目各模块中重复的低级 I/O 代码。
"""

import csv
import json
import os
from typing import Any, List, Optional, Union

import matplotlib.pyplot as plt
import numpy as np


def ensure_dir(path: Union[str, os.PathLike]) -> None:
    """保证文件所在目录存在。"""
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def to_serializable(obj: Any) -> Any:
    """将 numpy 类型等转为 JSON 可序列化类型。"""
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [to_serializable(i) for i in obj]
    return obj


def save_json(
    data: Any,
    path: Union[str, os.PathLike],
    **dump_kwargs,
) -> None:
    """将数据保存为 JSON 文件，自动处理 numpy 序列化。"""
    ensure_dir(path)
    kwargs = {"indent": 2, "ensure_ascii": False}
    kwargs.update(dump_kwargs)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(to_serializable(data), f, **kwargs)


def save_csv(
    rows: List[List[Any]],
    path: Union[str, os.PathLike],
    headers: Optional[List[str]] = None,
    sep: str = ",",
) -> None:
    """将二维行数据保存为 CSV 文件。"""
    ensure_dir(path)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, delimiter=sep)
        if headers:
            writer.writerow(headers)
        writer.writerows(rows)


def save_array_csv(
    data: Union[np.ndarray, List],
    path: Union[str, os.PathLike],
    header: Optional[str] = None,
    delimiter: str = ",",
    fmt: str = "%.6f",
) -> None:
    """将数组数据保存为 CSV 文件，使用 numpy.savetxt。"""
    ensure_dir(path)
    arr = np.asarray(data)
    kwargs = {"delimiter": delimiter, "comments": "", "fmt": fmt}
    if header is not None:
        kwargs["header"] = header
    np.savetxt(path, arr, **kwargs)


def save_figure(
    fig,
    path: Union[str, os.PathLike],
    dpi: int = 150,
    **kwargs,
) -> None:
    """统一封装 matplotlib 图像保存，默认参数集中管理。"""
    ensure_dir(path)
    defaults = {"bbox_inches": "tight"}
    defaults.update(kwargs)
    fig.savefig(path, dpi=dpi, **defaults)
    plt.close(fig)
