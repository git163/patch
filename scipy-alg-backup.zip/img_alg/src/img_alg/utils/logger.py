"""日志管理模块

提供静态函数接口的日志系统，支持：
1. 格式：[日期：时：分：秒][日志等级][进程id][线程id][文件名][日志信息]
2. 子进程输出到以进程 id 命名的不同文件
3. 支持 console 和日志文件切换
4. 支持自定义回调函数处理日志

使用示例:
    # 方式1：默认使用（输出到控制台）
    from img_alg.utils.logger import Logger
    Logger.info("处理完成")

    # 方式2：自定义回调
    def my_handler(msg: str):
        save_to_db(msg)
    Logger.setup(callback=my_handler)

    # 方式3：文件+回调
    Logger.setup(output_mode="file", callback=my_handler)
"""

import os
import sys
import threading
from datetime import datetime
from multiprocessing import current_process
from typing import Callable, Optional


               
def _default_print_callback(log_message: str):
    print(log_message)


class Logger:
    """
    日志管理器（静态函数接口）

    特性：
        1. 纯静态函数，无需实例化
        2. 初始化时设置回调，未设置则默认使用 print
        3. 支持文件/控制台/回调多种输出模式
    """

    _lock = threading.Lock()
    _initialized = False
    _callback: Optional[Callable[[str], None]] = None
    _config = {
        "log_level": "INFO",
        "output_mode": "console",                     
        "log_dir": "logs",
        "separate_process_logs": True
    }

    @classmethod
    def setup(cls,
              log_level: str = "INFO",
              output_mode: str = "console",
              log_dir: str = "logs",
              separate_process_logs: bool = True,
              callback: Optional[Callable[[str], None]] = None):
        """
        配置日志系统（类方法，只需调用一次）

        Args:
            log_level: 日志级别 DEBUG/INFO/WARNING/ERROR/CRITICAL
            output_mode: 输出模式 - console(仅控制台), file(仅文件), both(两者)
            log_dir: 日志文件存放目录
            separate_process_logs: 是否为子进程创建单独日志文件
            callback: 日志回调函数，接收格式化后的日志字符串，未设置则默认用 print
        """
        with cls._lock:
            cls._config.update({
                "log_level": log_level,
                "output_mode": output_mode,
                "log_dir": log_dir,
                "separate_process_logs": separate_process_logs
            })
                                 
            cls._callback = callback if callback else _default_print_callback
            cls._initialized = True

    @classmethod
    def _write_log(cls, level: str, msg: str, *args):
        """内部方法：格式化并输出日志"""
        if not cls._initialized:
            cls.setup()             

                
        level_order = {"DEBUG": 0, "INFO": 1, "WARNING": 2, "ERROR": 3, "CRITICAL": 4}
        current_level = cls._config.get("log_level", "INFO")
        if level_order.get(level, 0) < level_order.get(current_level, 1):
            return

               
        formatted_msg = msg % args if args else msg

                                                        
        now = datetime.now()
        timestamp = f"{now.year:04d}-{now.month:02d}-{now.day:02d}：{now.hour:02d}：{now.minute:02d}：{now.second:02d}"
        pid = os.getpid()
        tid = threading.current_thread().ident

                                        
        import inspect
        frame = inspect.currentframe().f_back.f_back                            
        filename = os.path.basename(frame.f_code.co_filename)

        log_line = f"[{timestamp}][{level}][{pid}][{tid}][{filename}]{formatted_msg}"

                          
        if cls._callback:
            try:
                cls._callback(log_line)
            except Exception:
                pass              

                   
        if cls._config["output_mode"] in ("file", "both"):
            cls._write_to_file(log_line)

    @classmethod
    def _write_to_file(cls, log_line: str):
        """写入日志文件"""
        log_dir = cls._config["log_dir"]
        os.makedirs(log_dir, exist_ok=True)

                   
        if cls._config["separate_process_logs"]:
            pid = os.getpid()
                      
            if current_process().name != "MainProcess":
                log_file = os.path.join(log_dir, f"img_alg_{pid}.log")
            else:
                log_file = os.path.join(log_dir, "img_alg.log")
        else:
            log_file = os.path.join(log_dir, "img_alg.log")

        with open(log_file, "a", encoding="utf-8") as f:
            f.write(log_line + "\n")

    @classmethod
    def debug(cls, msg: str, *args):
        """输出 DEBUG 级别日志"""
        cls._write_log("DEBUG", msg, *args)

    @classmethod
    def info(cls, msg: str, *args):
        """输出 INFO 级别日志"""
        cls._write_log("INFO", msg, *args)

    @classmethod
    def warning(cls, msg: str, *args):
        """输出 WARNING 级别日志"""
        cls._write_log("WARNING", msg, *args)

    @classmethod
    def error(cls, msg: str, *args):
        """输出 ERROR 级别日志"""
        cls._write_log("ERROR", msg, *args)

    @classmethod
    def critical(cls, msg: str, *args):
        """输出 CRITICAL 级别日志（总是输出）"""
        cls._write_log("CRITICAL", msg, *args)


        
Logger = Logger

                  
Logger.setup()
